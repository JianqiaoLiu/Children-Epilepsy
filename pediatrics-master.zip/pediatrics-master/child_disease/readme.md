# 环境搭建过程
## Mac

1. 安装homebrew: 方法 - http://brew.sh/

1. 打开一个终端，输入`brew install python python3`来安装python2.7 和python3

1. 在终端输入`pip -V` 检查`pip`有没有安装成功，成功的话会显示`pip`的版本号和`python`的版本号（应该是python 2.7）

1. 输入`pip install virtualenv virtualenvwrapper`安装了这个两个

1. 安装完`virtualenvwrapper`后，需要设置：
```
$ export WORKON_HOME=~/Envs
$ mkdir -p $WORKON_HOME
$ source /usr/local/bin/virtualenvwrapper.sh
```
1. 然后输入 `mkvirtualenv -p python3 pediatrics` 创建虚拟环境

1. 输入`workon pediatrics`切换到新创建的虚拟环境。切换成功的话，终端命令符前面会出现`(pediatrics)->`的前缀。

1. 这时候使用`pip install django mysqlclient`安装这两个库。

1. 安装`mysql`: 在终端输入 `brew install mysql` 就可以。

1. 创建数据库，使用mysql命令行工具进入数据库管理，然后创建名为`pediatrics`的数据库。

1. 修改 `child_disease/server/server/settings.py`配置文件中的数据库访问密码(87行)

1. 将终端`cd`到`child_disease/server`，然后输入`python manage.py makemigrations new_patient`

1. 上一步成功后，输入`python manage.py migrate`

1. 输入`python manage.py runserver`，启动开发服务器

1. `cd`到`child_disease/vue-frontend`，然后输入`npm install`，安装前端库

1. 输入`npm run build`编译前端代码。

1. 在浏览器中访问`localhost:8000`访问网页
