from django.contrib import admin

from . import models


def register_all():
    for name in dir(models):
        model = getattr(models, name)
        try:
            if (issubclass(model, models.models.Model) &
                    model._meta.abstract is False):
                admin.site.register(model)
        except:
            pass

register_all()
