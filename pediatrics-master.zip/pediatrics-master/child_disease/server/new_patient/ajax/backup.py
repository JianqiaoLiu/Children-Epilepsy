from django.http import HttpRequest, HttpResponse
from django_ajax.decorators import ajax
from ..models.record import Record
from ..models.backup import Backup


@ajax
def get_backup(req: HttpRequest):
    # model name
    model = req.POST.get('model')
    # field name
    field = req.POST.get('field')
    # patient/record id
    object_id = req.POST.get('object_id')

    entries = Backup.objects.filter(object_id=object_id, model=model, field=field).values()
    entries = list(entries)

    return entries


@ajax
def get_backup_by_id(req: HttpRequest):
    """
    get backup by patient/record id
    need to specify type and id
    :param req:
    :return:
    """
    object_id = req.POST.get('object_id')

    entries = list(Backup.objects.filter(object_id=object_id).values())

    return entries


@ajax
def get_backup_by_patient(req: HttpRequest):
    """
    get all the backup of a patient: including all records and medication and patient
    :param req:
    :return:
    """
    patient_id = req.POST.get('patient_id')
    record_ids = Record.objects.filter(patient__id=patient_id).values_list('id', flat=True)

    all_ids = [patient_id] + list(record_ids)

    entries = list(Backup.objects.filter(object_id__in=all_ids).values())
    return entries


@ajax
def update_backup(req: HttpRequest):
    """
    update/create backup
    :param req:
    :return:
    """
    # model name
    model = req.POST.get('model')
    # field name
    field = req.POST.get('field')
    # patient/record id
    object_id = req.POST.get('object_id')
    # text detail
    content = req.POST.get('content')

    obj, created = None, False

    obj, created = Backup.objects.update_or_create(
        object_id=object_id, field=field, model=model, content=content
    )

    return obj.id


@ajax
def delete_backup(req: HttpRequest):
    id = req.POST.get('id')

    delete_num, dic = Backup.objects.filter(id=id).delete()

    return delete_num
