from django.core.exceptions import ObjectDoesNotExist, FieldDoesNotExist
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.db.models import Model
from django.http import HttpRequest, HttpResponse
from datetime import date
from django_ajax.decorators import ajax

from .. import models
from .util import get_patient_models, get_json, is_reference_choice, is_concrete, get_record_models


def _update_model(model: Model, data: dict):
    """
    Updating a model using data.

    We don't update reverse relation data here.
    The reverse relation should be handle by related model
    from which the data views as concrete data

    e.g:
    Patient._meta.get_field('growth_history').concrete
    >> False
    Growth_History._meta.get_field('patient').concrete
    >> True

    :param data:
    :return:
    """

    obj = model()
    # first create the patient with non-relation data
    # because many-to-many fields can't assign if patient object
    # dose not exist in database
    for d in data:
        field = model._meta.get_field(d)
        if not field.many_to_many:
            if field.one_to_many or field.one_to_one or field.many_to_one:
                setattr(obj, d + '_id', data[d])
            else:
                setattr(obj, d, data[d])
    obj.save()

    for d in data:
        field = model._meta.get_field(d)
        if field.many_to_many:
            setattr(obj, d, data[d])
    obj.save()

    return obj


def _get_instance_values(instance=None):
    """
    Get all field values from an model object.

    Only recursively call itself when the object is a central model instance
    And the field is a relation field point to another model

    When *not* a central model instance, get only the ids for relation fields

    :param instance:
    :return:
    """
    if instance is None:
        return dict()
    if not isinstance(instance, Model):
        raise TypeError('Only model objects supported')

    fields = type(instance)._meta.get_fields()
    values = dict()

    for field in fields:
        # check if the field relate to a Option model
        # there are two situation when the related model is Option model
        # Diagnose foreign key and normal many-to-many option
        if is_reference_choice(field):
            if field.many_to_many:
                try:
                    related = getattr(instance, field.name)
                    values[field.name] = list(related.values_list('id', flat=True))
                except ValueError:
                    values[field.name] = []
            if field.many_to_one:
                # diagnose reference might be None
                related = getattr(instance, field.name)
                if related is None:
                    values[field.name] = None
                else:
                    values[field.name] = related.id
        elif is_concrete(field):
            if field.one_to_one or field.many_to_one:
                if hasattr(instance, field.name):
                    values[field.name] = getattr(instance, field.name).id
                else:
                    values[field.name] = None
            else:
                value = getattr(instance, field.name)
                # reformat the datetime object to string
                if isinstance(value, date):
                    value = "{:%Y-%m-%d}".format(value)
                if isinstance(value, Model):
                    value = value.pk
                values[field.name] = value

    return values


def _get_all_data_from_object(obj, related_models):
    """
    Get all the data from a model object
    may including all the related model data

    if related models is None, only get the object regular data

    :param obj:
    :param related_models: an array to control which related model is include.
    :return:
    """
    obj_model = type(obj)
    data = dict()
    for model in related_models:
        attribute_name = model.__name__.lower()
        if hasattr(obj, attribute_name):
            instance = getattr(obj, attribute_name)
            data[model.__name__] = _get_instance_values(instance)
        elif hasattr(obj, attribute_name + '_set'):
            # related manger
            instances = getattr(obj, attribute_name + '_set').all()
            data[model.__name__] = [_get_instance_values(instance)
                                    for instance in instances]
        else:
            # empty initialize
            try:
                obj_model._meta.get_field(attribute_name)
                data[model.__name__] = _get_instance_values(model())
                # also we add the main model id, so that model update will work
                data[model.__name__][obj_model.__name__.lower()] = obj.id
            except FieldDoesNotExist:
                pass

    # add record basic data itself
    data[obj_model.__name__] = _get_instance_values(obj)

    return data


@ajax
def get_patient_data(req: HttpRequest):
    """
    get ONE patient information not including
    Record information

    this won't cover A-B-C relationship where
    A is one-to-one with B
    B is one-to-one with C
    one level relationship is considered only

    :param req:
    :return:
    """

    patient_id = req.POST.get('id')

    patient_models = get_patient_models()
    record_models = get_record_models()

    try:
        patient = models.Patient.objects.get(pk=patient_id)
    except ObjectDoesNotExist:
        patient = models.Patient()

    # first get the values for Record object
    return {
        'patient': _get_all_data_from_object(patient, patient_models),
        'records': {
            record.id: _get_all_data_from_object(record, record_models)
            for record in patient.record_set.all()
        },
        'medications': {
            medication.id: _get_all_data_from_object(medication, (models.Medication,))
            for medication in patient.medication_set.all()
        }
    }


@ajax
def update_model(req):
    data = get_json(req)
    model_name = data.get('model_name')
    datum = data.get('data')

    new_object = None
    if hasattr(models, model_name):
        model = getattr(models, model_name)
        if datum is not None:
            new_object = _update_model(model, datum)

    return new_object and new_object.pk


@ajax
def get_patient_records(req):
    """
    get the records of a patient
    with pagination
    :param req:
    :return:
    """
    patient_id = req.POST.get('id')
    simple_records = models.Record.objects.filter(patient__id=patient_id).select_related('eeg__result').values()
    for record in simple_records:
        record['date'] = "{:%Y-%m-%d}".format(record['date'])

    return {
        record['id']: record
        for record in simple_records
    }


@ajax
def get_record_detail(req):
    record_id = req.POST.get('id')
    patient_id = req.POST.get('patientId')
    related_models = get_record_models()

    try:
        record = models.Record.objects.get(id=record_id)
    except ObjectDoesNotExist:
        record = models.Record()
        record.patient_id = patient_id

    return _get_all_data_from_object(record, related_models)


@ajax
def get_medication_by_record(req):
    record_id = req.POST.get('id')
    return {
        med.id: med
        for med in models.Medication.objects.filter(record=record_id).values()
    }

@ajax
def create_record(req):
    data = get_json(req)
    patient_id = data.get('patientId')
    data = data.get('record').get('Record')
    data['patient_id'] = patient_id

    new_record = _update_model(models.Record, data)
    return new_record.id


@ajax
def delete_model(req):
    id = req.POST.get('id')
    model = req.POST.get('model')
    if hasattr(models, model):
        getattr(models, model).objects.filter(id=id).delete()
        return id
    return None
