from django.http import HttpRequest

from .util import  get_all_models, get_field_verbose_name, get_choices, is_multiple_choice, get_editable_fields
from django_ajax.decorators import ajax


@ajax
def initialize(req: HttpRequest):
    """
    get all the model and field meta data for initialize
    :return:
    """
    all_models = get_all_models()
    verbose = {
        model.__name__: model._meta.verbose_name
        for model in all_models
    }
    verbose = dict({
        field.name: get_field_verbose_name(field)
        for model in all_models
        for field in get_editable_fields(model)
    }, **verbose)

    meta = {}

    for model in all_models:
        order = 0
        meta = dict(meta, **{
            model.__name__: {}
        })
        for field in get_editable_fields(model):
            if field.help_text:
                ary = field.help_text.split('|')
                try:
                    suffix = ary[1]
                except IndexError:
                    suffix = None
                help_text = ary[0]
            else:
                suffix = help_text = None

            meta[model.__name__] = dict(meta[model.__name__], **{
                field.name: {
                    'model': model.__name__,
                    'name': field.name,
                    'order': order,
                    'django_type': field.get_internal_type(),
                    # Database auto created fields or fields with name exactly
                    # equal to 'id' is considered an Auto filed
                    'auto': field.auto_created or field.name == 'id',
                    # Django choices and he reference field to a 'Option_' table
                    'choices': get_choices(field),
                    'nullable': field.null,
                    'blankable': field.blank,
                    'suffix': suffix,
                    'help_text': help_text,
                    'max_length': field.max_length,
                    'multiple': is_multiple_choice(field)
                }
            })
            order += 1
    ret = {
        "meta": meta,
        "verbose": verbose
    }
    return ret
