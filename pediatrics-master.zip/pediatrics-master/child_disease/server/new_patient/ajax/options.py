from django.core.exceptions import ObjectDoesNotExist
from django.http import HttpRequest, HttpResponse
from django_ajax.decorators import ajax
from .util import get_models_by_name, get_option_models
from .. import models


@ajax
def get_options(req: HttpRequest):
    """
    load all options
    :param req:
    :return:
    """
    return {
        model.__name__: {
            val['id']: val
            for val in
            model.objects.all().values()
        }
        for model
        in get_option_models()
    }


@ajax
def update_option(req: HttpRequest):
    """
    add/update an option to a option table

    when update, id must be provided.
    tableName must be provided in either case.

    :param req: {option_type, id, [form]}
    :return:
    """

    model = getattr(models, req.POST.get('option_type'))

    try:
        option = model.objects.get(id=req.POST.get('id'))
        option.name = req.POST.get('name')

    except (KeyError, ObjectDoesNotExist):
        option = model(name=req.POST.get('name'))
        option.save()

    return option.id


@ajax
def delete_option(req: HttpRequest):
    """
    delete an option identified by id

    actually this method won't be used a lot since
    option table reference will prevent deleting of
    referee

    :param req:
    :return:
    """

    model_name = req.POST.get('option_type')
    id = req.POST.get('id')
    model = get_models_by_name(model_name)
    model.objects.filter(id=id).delete()
    return id
