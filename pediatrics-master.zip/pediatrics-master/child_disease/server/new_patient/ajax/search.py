from django.db.models import Q
from django.core.exceptions import FieldError
from django.http import HttpRequest
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django_ajax.decorators import ajax
from . import models


def _is_direct_related(model_a, model_b):
    model_a_related_models = tuple(
        obj.related_model
        for obj in model_a._meta.related_objects
    )
    return model_b in model_a_related_models


@ajax
def search_patient(req: HttpRequest):
    """
    search patients with a string where patient.id
    or patient.name contains

    :param req:
    :return:
    """
    search_query = req.POST.get('query')
    search_model = req.POST.get('model')
    search_field = req.POST.get('field')
    page_num = req.POST.get('page_num')
    per_page = req.POST.get('per_page')

    if search_model and search_field:
        if search_model == 'Patient':
            search_filter = {
                search_field: search_query
            }
        elif _is_direct_related(models.Patient, getattr(models, search_model)):
            search_filter = {
                search_model.lower() + '__' + search_field: search_query
            }
        else:
            search_filter = {
                'record__' + search_model.lower() + '__' + search_field: search_query
            }
        patients = models.Patient.objects.filter(**search_filter).distinct()

    else:
        patients = models.Patient.objects.filter(
            Q(id__contains=search_query) |
            Q(patient_name__contains=search_query))

    paginator = Paginator(patients, per_page)

    try:
        page = paginator.page(page_num)
    except PageNotAnInteger:
        page = paginator.page(1)
    except EmptyPage:
        page = paginator.page(paginator.num_pages)

    items = list()

    for p in page.object_list:
        records = list()
        if search_model and search_field:
            if _is_direct_related(models.Record, getattr(models, search_model)):
                # for attribute that exist in Record model
                search_filter = {
                    search_model.lower() + '__' + search_field: search_query
                }

                record_query_set = p.record_set.filter(**search_filter)
                # for attribute that exist in related model of Record, here typically in 'Eeg'
                try:
                    records = [{
                                   'id': record['id'],
                                   'date': '{:%Y-%m-%d}'.format(record['date']),
                                   'extra': record[search_model.lower() + '__' + search_field]}
                               for record in
                               record_query_set.values('id', 'date', search_model.lower() + '__' + search_field)
                               ]
                except FieldError:
                    pass

            elif search_model == 'Record':
                search_filter = {
                    search_field: search_query
                }

                record_query_set = p.record_set.filter(**search_filter)
                # for attribute that exist in related model of Record, here typically in 'Eeg'
                try:
                    records = [{
                                   'id': record['id'],
                                   'date': '{:%Y-%m-%d}'.format(record['date']),
                                   'extra': record[search_field]}
                               for record in
                               record_query_set.values('id', 'date', search_field)
                               ]
                except FieldError:
                    pass

        items.append({
            'id': p.id,
            'patient_name': p.patient_name,
            'birth_date': '{:%Y-%m-%d}'.format(p.birth_date),
            'gender': p.gender,
            'num_records': p.record_set.count(),
            'records': records
        })

    return {
        'items': items,
        'num_pages': paginator.num_pages,
        'num_patients': patients.count()
    }
