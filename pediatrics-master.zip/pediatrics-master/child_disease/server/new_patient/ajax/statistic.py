from django.http import HttpRequest, HttpResponse
from django.db.models import Count
from ..models import Patient, Record, Eeg, Medication, Option_Diagnose
from .util import response_json

def total(req):
    total_patients = Patient.objects.count()
    total_records = Record.objects.count()
    total_eegs = Record.objects.count()

    return response_json({
        "total_patients": total_patients,
        "total_records": total_records,
        "total_eegs": total_eegs
    })


def statistic_segment(req):
    """
    对连续的数据选择某个区间, 按照某个间隔进行统计
    :return:
    """
    min = req.POST.get('min')
    max = req.POST.get('max')
    step = req.POST.get('step')
    item = req.POST.get('item')


def statistic_category(req):
    """
    对离散数据全部进行分类统计
    :return:
    """
    item = req.POST.get('item')
    result = None
    if item == 'diagnose':
        pass
        #up coming
    elif item == 'gender':
        result = Patient.objects.order_by('gender').distinct().values('gender').annotate(Count('gender'))
    elif item == 'medicine':
        result = Patient.objects.values('record__medicine').annotate(Count('record__medicine'))

    return response_json(list(result))
