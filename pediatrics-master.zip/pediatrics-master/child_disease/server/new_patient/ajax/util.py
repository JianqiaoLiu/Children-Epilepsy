import json
from inspect import isclass

from django.db.models import Field, Model
from django.http import HttpResponse
from new_patient.models import patient, record

from .. import models


def get_json(req):
    if req.META['CONTENT_TYPE'] == 'application/json;utf-8':
        return json.loads(req.body.decode('utf-8'))


def response_json(data):
    return HttpResponse(json.dumps(data, ensure_ascii=False), content_type='application/json')


def is_option_model(model) -> bool:
    return isclass(model) and issubclass(model, models.Option) and model != models.Option


def is_concrete(field: Field) -> bool:
    """
    determine if a field should show in the form with values
    including native `concrete` field and multiple choice field
    :param field:
    :return:
    """
    return (field.concrete and not field.one_to_many) or \
           is_reference_choice(field)


def is_reference_choice(field: Field) -> bool:
    """

    :param field:
    :return:
    """
    return is_option_model(field.related_model)


def get_patient_models():
    """
    get all the models in models/patient.py
    :return:
    """
    return tuple(obj.related_model for obj in models.Patient._meta.related_objects) + (models.Patient,)


def get_record_models():
    """
    get all the models in models/record.py
    :return:
    """
    return tuple(obj.related_model for obj in models.Record._meta.related_objects) + (models.Record,)


def get_option_models(option_types=None):
    """
    get all the models that is a sub-model of Option
    :param option_types:
    :return:
    """
    return tuple(
        getattr(models, model_name)
        for model_name
        in dir(models)
        if is_option_model(getattr(models, model_name)) and
        (option_types is None or model_name in option_types)
    )


def is_multiple_choice(field: Field) -> bool:
    """
    test if the field is multiple choice
    :param field:
    :return:
    """
    return is_reference_choice(field) and field.many_to_many


def get_field_verbose_name(field: Field):
    """
    if the field.verbose_name exist, we use it
    if it is a multiple choice, which is a no-verbose-name
    foreign key, we go fetch the name of its
    related model

    :param field:
    :return:
    """

    if is_reference_choice(field):
        return field.related_model._meta.verbose_name

    return field.verbose_name


def get_editable_fields(model: Model):
    return tuple(
        field for field
        in model._meta.get_fields()
        if is_concrete(field) and
        not field.is_relation or
        is_reference_choice(field)
    )


def get_choices(field):
    if is_reference_choice(field):
        choices = [
            {'name': choice['name'], 'id': choice['id']}
            for choice
            in field.related_model.objects.values()
            ]
    else:
        choices = [
            {'name': choice[1], 'id': choice[0]}
            for choice
            in field.choices
            ]

    return choices


def get_all_models():
    return get_option_models() + get_patient_models() + get_record_models()


def get_models_by_name(model_names=None):
    """
    return the model by given name(s)
    if multiple name is provided in list, return a list of models object

    if one name is provieded as string, return one model object
    :param model_names:
    :return:
    """
    if model_names is None:
        return get_all_models()

    if isinstance(model_names, str):
        return getattr(models, model_names)

    return tuple(
        getattr(models, model_name)
        for model_name
        in model_names
    )
