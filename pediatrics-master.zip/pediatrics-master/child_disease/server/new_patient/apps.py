from django.apps import AppConfig


class NewPatientConfig(AppConfig):
    name = 'new_patient'
