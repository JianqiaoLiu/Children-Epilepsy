from django.db import models

class Backup(models.Model):
    """
    A backup model for patient
    """
    # text detail
    content = models.TextField(blank=True, null=True)

    # using model, and field name to locate a backup
    # object_id can be medication id, record id or patient id
    object_id = models.CharField(max_length=12)
    # model
    model = models.CharField(max_length=50)
    # field name
    field = models.CharField(max_length=50)


