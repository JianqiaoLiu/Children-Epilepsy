from django.db import models
from django.utils import timezone
from .share import Option

class Option_Similar_Disease(Option):
    class Meta:
        verbose_name = "相似疾病"
        verbose_name_plural = "相似疾病"


class Option_Inbreeding(Option):
    class Meta:
        verbose_name = "近亲婚配"
        verbose_name_plural = "近亲婚配"


class Patient(models.Model):
    """病人基本信息对象"""

    # TODO: ethic group
    ETHIC_GROUP_CHOICE = (
        (1, '汉族'),
        (2, '蒙古族'),
        (3, '回族'),
        (4, '藏族'),
        (5, '维吾尔族'),
        (6, '苗族'),
        (7, '彝族'),
        (8, '壮族'),
        (9, '布依族'),
        (10, '朝鲜族'),
        (11, '满族'),
        (12, '侗族'),
        (13, '瑶族'),
        (14, '白族'),
        (15, '土家族'),
        (16, '哈尼族'),
        (17, '哈萨克族'),
        (18, '傣族'),
        (19, '黎族'),
        (20, '傈僳族'),
        (21, '佤族'),
        (22, '畲族'),
        (23, '拉祜族'),
        (24, '水族'),
        (25, '东乡族'),
        (26, '纳西族'),
        (27, '景颇族'),
        (28, '柯尔克孜族'),
        (29, '土族'),
        (30, '达斡尔族'),
        (31, '仫佬族'),
        (32, '羌族'),
        (33, '布朗族'),
        (34, '撒拉族'),
        (35, '毛南族'),
        (36, '仡佬族'),
        (37, '锡伯族'),
        (38, '阿昌族'),
        (39, '普米族'),
        (40, '塔吉克族'),
        (41, '怒族'),
        (42, '乌兹别克族'),
        (43, '俄罗斯族'),
        (44, '鄂温克族'),
        (45, '德昂族'),
        (46, '保安族'),
        (47, '裕固族'),
        (48, '京族'),
        (49, '塔塔尔族'),
        (50, '独龙族'),
        (51, '鄂伦春族'),
        (52, '赫哲族'),
        (53, '门巴族'),
        (54, '珞巴族'),
        (55, '基诺族'),
        (56, '高山族')
    )

    (NORMAL, SLIGHT, MEDIUM, SEVERE) = range(1, 5)
    INTELLIGENCE_ASSESS = (
        (NORMAL, '正常'),
        (SLIGHT, '轻度'),
        (MEDIUM, '中度'),
        (SEVERE, '重度')
    )

    (MALE, FEMALE) = range(1, 3)
    GENDER = (
        (MALE, '男'),
        (FEMALE, '女')
    )

    # TODO: generate the id
    id = models.CharField(max_length=12, primary_key=True, db_index=True)
    hospitalize_id = models.CharField(max_length=20, verbose_name='住院号', null=True)

    patient_name = models.CharField(verbose_name='姓名', max_length=30)
    gender = models.PositiveSmallIntegerField(verbose_name='性别', choices=GENDER)
    outbreak_age = models.PositiveIntegerField(verbose_name='发病年龄', help_text='|岁')
    birth_date = models.DateField(verbose_name='出生日期')
    ethic_group = models.PositiveIntegerField(verbose_name='民族',
                                              choices=ETHIC_GROUP_CHOICE)
    weight = models.FloatField(verbose_name='体重', null=True, blank=True, help_text='|斤')
    height = models.PositiveIntegerField(verbose_name='身高',
                                         null=True, blank=True, help_text='|厘米')
    head_size = models.PositiveIntegerField(verbose_name='头围',
                                            null=True, blank=True, help_text='|厘米')
    intelligence_assess = models.PositiveIntegerField(choices=INTELLIGENCE_ASSESS, verbose_name='智力检查', null=True, blank=True)


    def __str__(self):
        return '%s' % self.patient_name

    @classmethod
    def _generate_id(cls):
        """
        Generate the id for patient.
        The id is consist of:
        [Year][Month][Day][4 digit]
        :return:
        """

        now = timezone.now()
        num = 0

        latest = Patient.objects.last()

        if latest is not None:
            if '{:%Y%m%d}'.format(now) == latest.id[:8]:
                num = int(latest.id[-4:]) + 1
        return Patient._format_id(now, num)

    @classmethod
    def _format_id(cls, date, number):
        return '{:%Y%m%d}{:04d}'.format(date, number)


    def save(self, *args, **kwargs):
        # make sure to generate a new custom id when creating patient
        if self.id is None or len(self.id) != 12:
            self.id = Patient._generate_id()
        super(Patient, self).save(*args, **kwargs)

    class Meta:
        verbose_name = "病人基本信息"
        verbose_name_plural = "病人基本信息"
        ordering = ['id']


class Family(models.Model):
    """家族史"""
    patient = models.OneToOneField(Patient, primary_key=True, on_delete=models.CASCADE)
    similar_disease = models.ManyToManyField(Option_Similar_Disease)
    inbreeding = models.ManyToManyField(Option_Inbreeding)
    backup = models.CharField(verbose_name='备注', blank=True, max_length=500, null=True)
    class Meta:
        verbose_name = "家族史"
        verbose_name_plural = "家族史"


class Growth_History(models.Model):
    patient = models.OneToOneField(Patient, primary_key=True, on_delete=models.CASCADE)

    raise_head = models.PositiveSmallIntegerField(null=True, verbose_name='抬头', help_text='|月')
    laugh = models.PositiveSmallIntegerField(null=True, verbose_name='大笑', help_text='|月')
    turn_over = models.PositiveSmallIntegerField(null=True, verbose_name='翻身', help_text='|月')
    grab = models.PositiveSmallIntegerField(null=True, verbose_name='抓物', help_text='|月')
    sit = models.PositiveSmallIntegerField(null=True, verbose_name='独坐', help_text='|月')
    crawl = models.PositiveSmallIntegerField(null=True, verbose_name='爬', help_text='|月')
    walk = models.PositiveSmallIntegerField(null=True, verbose_name='独走', help_text='|月')
    talk = models.PositiveSmallIntegerField(null=True, verbose_name='说话', help_text='|月')

    class Meta:
        verbose_name = '个人史'
        verbose_name_plural = '个人史'


class Pregnant_History(models.Model):
    patient = models.OneToOneField(Patient, primary_key=True, on_delete=models.CASCADE)
    pregnant_age = models.PositiveSmallIntegerField(verbose_name='母孕年龄', help_text='|岁')
    pregnant_times = models.PositiveSmallIntegerField(verbose_name='怀孕次数', help_text='|次')
    labor_times = models.PositiveSmallIntegerField(verbose_name='生产次数', help_text='|次')
    cold = models.NullBooleanField(verbose_name='感冒', help_text='怀孕期间有无得过感冒')
    hypertension = models.NullBooleanField(verbose_name='高血压', help_text='怀孕期间有无出现高血压')
    diabetes = models.NullBooleanField(verbose_name='糖尿病', help_text='怀孕期间有无得过糖尿病')
    leg_convulsion = models.NullBooleanField(verbose_name='腿抽筋', help_text='怀孕期间有无出现腿抽筋')
    tocolytic = models.NullBooleanField(verbose_name='使用保胎药', help_text='怀孕期间有无用过保胎药')
    appetite = models.NullBooleanField(verbose_name='妊娠反应', help_text='怀孕期间有无出现妊娠反应')
    backup = models.CharField(max_length=500, blank=True, verbose_name='备注', null=True)

    class Meta:
        verbose_name = "母孕史"
        verbose_name_plural = "母孕史"


class Labor_History(models.Model):
    """生产史"""

    (SUFFICIENT, LACK) = range(1, 3)
    SUFFICIENT_MONTH = (
        (SUFFICIENT, '是'),
        (LACK, '否')
    )
    patient = models.OneToOneField(Patient, primary_key=True, on_delete=models.CASCADE)

    pregnant_weeks = models.PositiveSmallIntegerField(verbose_name='孕周', help_text='|周')
    sufficient_month = models.PositiveSmallIntegerField(
        verbose_name='是否足月',
        choices=SUFFICIENT_MONTH,
        help_text='怀孕足月还是早产'
    )
    expect_labor_offset = models.IntegerField(
        verbose_name='离预产期',
        help_text='实际产期距离预产期多少天, 正数代表延后, 负数代表提前|天')
    natural_labor = models.BooleanField(verbose_name='顺产')

    SUFFOCATION_NONE = 1
    SUFFOCATION_SLIGHT = 2
    SUFFOCATION_SEVERE = 3
    SUFFOCATION = (
        (SUFFOCATION_NONE, '无窒息'),
        (SUFFOCATION_SLIGHT, '轻度窒息'),
        (SUFFOCATION_SEVERE, '严重窒息')
    )

    suffocation = models.PositiveSmallIntegerField(verbose_name='窒息情况',
                                                   choices=SUFFOCATION)
    birth_weight = models.PositiveSmallIntegerField(verbose_name='出生体重', help_text='|斤')
    amniotic_pollution = models.NullBooleanField(verbose_name='羊水污染')
    bilirubin_encephalopathy = models.NullBooleanField(verbose_name='胆红素脑病')
    neonatal_jaundice = models.NullBooleanField(verbose_name='新生儿黄疸')
    feeding_trouble = models.NullBooleanField(verbose_name='喂养困难')
    disgorge = models.NullBooleanField(verbose_name='呕吐')
    diarrhea = models.NullBooleanField(verbose_name='腹泻')
    nutrition = models.NullBooleanField(verbose_name='补充鱼肝油')
    backup = models.CharField(max_length=500, blank=True, verbose_name='备注', null=True)

    class Meta:
        verbose_name = "生产史"
        verbose_name_plural = "生产史"


class Disease_History(models.Model):
    patient = models.OneToOneField(Patient,primary_key=True, on_delete=models.CASCADE)

    first_outbreak_date = models.DateField(verbose_name='首次发作日期')
    outbreak_times = models.SmallIntegerField(verbose_name='发作次数', help_text='|次')
    outbreak_sleeping = models.CharField(max_length=500, blank=True, verbose_name='睡眠中发作')
    last_outbreak_date = models.DateField(verbose_name='最后发作日期')

    medication_time = models.PositiveSmallIntegerField(verbose_name='用药时间')
    backup = models.CharField(max_length=500, blank=True, verbose_name='备注', null=True)

    class Meta:
        verbose_name = "现病史"
        verbose_name_plural = "现病史"


class Option_Medication_Name(Option):
    """药名"""

    class Meta:
        verbose_name = "药物"
        verbose_name_plural = "药物"


class Medication(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    medicine = models.ForeignKey(Option_Medication_Name)

    start_date = models.DateField(verbose_name="开始服药时间")
    end_date = models.DateField(verbose_name="结束服药时间", null=True)
    dose = models.PositiveSmallIntegerField(verbose_name="剂量", null=True)

    backup = models.CharField(max_length=500, blank=True, verbose_name='备注', null=True)

    class Meta:
        verbose_name = "用药记录"
        verbose_name_plural = "用药记录"
