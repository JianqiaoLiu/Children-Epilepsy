from django.db import models
from .patient import Patient
from .share import Option


class Option_Diagnose(Option):
    class Meta:
        verbose_name = "诊断"
        verbose_name_plural = "诊断"


class Record(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    date = models.DateField(verbose_name='日期')

    special_access = models.TextField(verbose_name='特殊检查', blank=True)
    gene_assess = models.TextField(verbose_name='基因检查', blank=True)
    metabolism_assess = models.TextField(verbose_name='代谢检查', blank=True)

    diagnose = models.ForeignKey(Option_Diagnose, null=True, blank=True)

    class Meta:
        verbose_name = "就诊记录"
        verbose_name_plural = "就诊记录"


class Option_Outbreak_Case(Option):
    class Meta:
        verbose_name = "发作类型选项"
        verbose_name_plural = "发作类型选项"


class Outbreak(models.Model):
    record = models.OneToOneField(Record, primary_key=True, on_delete=models.CASCADE)

    outbreak_times = models.PositiveSmallIntegerField(
        verbose_name='发作次数', help_text='距离本次就医之前大概发作次数'
    )
    outbreak_description = models.CharField(max_length=500, blank=True, verbose_name='发作情况')
    first_outbreak_date = models.DateField(verbose_name="首次发作日期", null=True)
    last_outbreak_date = models.DateField(verbose_name='最后发作日期', null=True)
    outbreak_max_duration = models.PositiveIntegerField(
        verbose_name='发作最长持续时间', null=True,
        help_text='所有发作中持续最长的时间|秒'
    )
    outbreak_min_duration = models.PositiveIntegerField(
        verbose_name='发作最短持续时间', null=True,
        help_text='所有发作中持续最短的时间|秒'
    )
    OUTBREAK_SLEEPING = (
        (1, '清醒'),
        (2, '睡眠'),
        (3, '清醒和睡眠并存')
    )
    # how to make this work
    outbreak_sleeping = models.CommaSeparatedIntegerField(
        verbose_name='睡眠中发作', max_length=2, choices=OUTBREAK_SLEEPING
    )

    (FREQUENT, RARE) = range(1, 3)
    OUTBREAK_FREQUENCY = (
        (FREQUENT, '频繁'),
        (RARE, '少量')
    )
    outbreak_frequency = models.PositiveSmallIntegerField(
        verbose_name='发作频率', choices=OUTBREAK_FREQUENCY
    )
    outbreak_case = models.ManyToManyField(Option_Outbreak_Case)
    backup = models.CharField(max_length=500, blank=True, verbose_name='备注', null=True)

    class Meta:
        verbose_name = "发作情况"
        verbose_name_plural = "发作情况"


class Option_Mri_Basal_Nuclei(Option):
    """影像学检查 - 基底核团选项"""

    class Meta:
        verbose_name = "MRI基底核团"
        verbose_name_plural = "MRI基底核团"


class Option_Mri_Fortify(Option):
    class Meta:
        verbose_name = "MRI强化"
        verbose_name_plural = "MRI强化"


class Ct(models.Model):

    (LOW_DENSITY_NEUTRAL_VARIABLE, LOW_DENSITY_OVERALL, LOW_DENSITY_PARTIAL) = range(1, 4)
    LOW_DENSITY = (
        (LOW_DENSITY_OVERALL, '广泛'),
        (LOW_DENSITY_PARTIAL, '局限')
    )

    (BLEEDING, CALCIFY) = range(1, 3)
    HIGH_DENSITY = (
        (BLEEDING, '出血'),
        (CALCIFY, '钙化')
    )

    (VENTRICLE_NORMAL, VENTRICLE_EXPANDING) = range(1, 3)
    VENTRICLE = (
        (VENTRICLE_NORMAL, '正常'),
        (VENTRICLE_EXPANDING, '扩大')
    )

    record = models.OneToOneField(Record, primary_key=True)
    check_id = models.CharField(unique=True, max_length=20, verbose_name='检查号')

    low_density = models.PositiveSmallIntegerField(
        verbose_name='低密度',
        null=True,
        choices=LOW_DENSITY
    )
    high_density = models.PositiveSmallIntegerField(
        verbose_name='高密度',
        null=True,
        choices=HIGH_DENSITY
    )
    ventricle = models.PositiveIntegerField(
        verbose_name='脑室',
        choices=VENTRICLE
    )

    backup = models.CharField(max_length=500, blank=True, verbose_name='备注', null=True)

    class Meta:
        verbose_name = "CT"
        verbose_name_plural = "CT"


class Mri(models.Model):

    record = models.OneToOneField(Record, primary_key=True)
    check_id = models.CharField(unique=True, max_length=20, verbose_name='检查号')

    (WHITE_CORTEX_NORMAL, WHITE_CORTEX_SWOLLEN, WHITE_CORTEX_CYSTIC, WHITE_CORTEX_DEMYELINATION_PARTIAL,
     WHITE_CORTEX_DEMYELINATION_OVERALL) = range(1, 6)

    WHITE_CORTEX = (
        (WHITE_CORTEX_NORMAL, '正常'),
        (WHITE_CORTEX_SWOLLEN, '水肿'),
        (WHITE_CORTEX_CYSTIC, '囊性'),
        (WHITE_CORTEX_DEMYELINATION_PARTIAL, '局部脱髓鞘'),
        (WHITE_CORTEX_DEMYELINATION_OVERALL, '广泛脱髓鞘')
    )

    (CORTEX_NORMAL, CORTEX_ATROPHY, CORTEX_RETARDATION) = range(1, 4)
    CORTEX = (
        (CORTEX_NORMAL, '正常'),
        (CORTEX_ATROPHY, '萎缩'),
        (CORTEX_RETARDATION, '发育落后')
    )

    cortex = models.PositiveIntegerField(verbose_name='皮层', choices=CORTEX)
    date = models.DateField(verbose_name='日期')
    white_cortex = models.PositiveSmallIntegerField(
        verbose_name='白质',
        choices=WHITE_CORTEX
    )
    basal_nuclei = models.ManyToManyField(Option_Mri_Fortify)
    fortify = models.ManyToManyField(Option_Mri_Basal_Nuclei)

    backup = models.CharField(max_length=500, blank=True, verbose_name='备注', null=True)

    class Meta:
        verbose_name = "MRI"
        verbose_name_plural = "MRI"

class Option_EEG_Background(Option):
    pass

    class Meta:
        verbose_name = "背景类型"
        verbose_name_plural = "背景类型"

class Option_EEG_Discharge(Option):
    class Meta:
        verbose_name = "电发作类型"
        verbose_name_plural = "电发作类型"


class Option_EEG_Abnormal(Option):
    class Meta:
        verbose_name = "异常波选项"
        verbose_name_plural = "异常波选项"


class Eeg(models.Model):
    """
    脑电图
    """
    record = models.OneToOneField(Record, primary_key=True, on_delete=models.CASCADE)
    eeg_id = models.CharField(verbose_name="脑电图ID", primary_key=False, max_length=30)
    date = models.DateField(verbose_name="日期")

    outbreak_monitor = models.CharField(max_length=500, verbose_name="监测中有临床发作", blank=True)
    corroborate = models.BooleanField(verbose_name="与家长描述一致")

    (MULTIPLE_WAVE, SLOW_WAVE) = range(1, 3)
    # 癫痫发作波
    epilepsy = models.CharField(max_length=500, blank=True, verbose_name="发作期脑电图")
    epilepsy_duration = models.PositiveIntegerField(verbose_name="痫性发作时间")
    discharge_duration = models.PositiveIntegerField(verbose_name="放电持续时间")

    background = models.ManyToManyField(Option_EEG_Background, verbose_name='脑电图背景情况')
    abnormal = models.ManyToManyField(Option_EEG_Abnormal, verbose_name='发作期间异常波')
    discharge = models.ManyToManyField(Option_EEG_Discharge, verbose_name='电发作情况')

    RESULT = (
        (1, '异常'),
        (2, '界限'),
        (3, '正常')
    )
    result = models.PositiveSmallIntegerField(verbose_name='脑电图印象', choices=RESULT)

    backup = models.CharField(max_length=500, blank=True, verbose_name='备注', null=True)

    class Meta:
        verbose_name = "脑电图"
        verbose_name_plural = "脑电图"


class Prognosis(models.Model):
    record = models.OneToOneField(Record, primary_key=True, on_delete=models.CASCADE)

    CLINICAL_EFFECT = (
        (1, '完全控制'),
        (2, '减少50% 以上'),
        (3, '减少25% - 50%'),
        (4, '减少25% 以下'),
        (5, '未控制'),
        (6, '恶化')
    )

    EEG_EFFECT = (
        (1, '未见放电'),
        (2, '放电减少'),
        (3, '放电不变'),
        (4, '放电增加'),
        (5, '放电形式变化'),
    )

    clinical_prognosis = models.PositiveSmallIntegerField(
        choices=CLINICAL_EFFECT,
        verbose_name='临床预后'
    )
    eeg_prognosis = models.PositiveSmallIntegerField(
        choices=EEG_EFFECT,
        verbose_name="脑电图预后"
    )
    relapse = models.PositiveSmallIntegerField(verbose_name="每月复发次数")
    backup = models.CharField(max_length=500, blank=True, verbose_name='备注', null=True)

    class Meta:
        verbose_name = "疗效"
        verbose_name_plural = "疗效"
