from django.db import models

class Option(models.Model):
    name = models.CharField(max_length=50)

    class Meta:
        abstract = True
