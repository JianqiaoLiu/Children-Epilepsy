from django.test import TestCase, Client
from django.core.urlresolvers import reverse
import json
from django.utils import timezone
from . import models, ajax
from .ajax import util

client = Client()

def post(fn, data=None):
    """
    shortcut post function
    :param fn:
    :param data:
    :return:
    """
    res = client.post(reverse(fn), data, HTTP_X_REQUESTED_WITH='XMLHttpRequest')
    if res['Content-Type'] == 'application/json':
        return res.json()
    else:
        return res.content.decode('utf-8')


def post_json(fn, data=None):
    """
    shortcut function for json request
    :param fn:
    :param data:
    :return:
    """
    res = client.post(reverse(fn), json.dumps(data),
                      HTTP_X_REQUESTED_WITH='XMLHttpRequest',
                      content_type='application/json;utf-8')
    if res['Content-Type'] == 'application/json':
        return res.json()
    else:
        return res.content.decode('utf-8')


class OptionSettings(TestCase):
    @classmethod
    def setUpTestData(cls):
        models.Option_Outbreak_Case.objects.create(name="test 1")
        models.Option_Outbreak_Case.objects.create(name="test 2")
        models.Option_Outbreak_Case.objects.create(name="test 3")

    def test_random_option_added_in_ASCII(self):
        post(ajax.update_option, {
            'option_type': 'Option_Outbreak_Case',
            'name': 'test A'
        })

        self.assertEqual(
            models.Option_Outbreak_Case.objects.filter(name='test A').count(),
            1)

    def test_random_option_added_in_Unicode(self):
        post(ajax.update_option, {
            'option_type': 'Option_Outbreak_Case',
            'name': '测试'
        })

        self.assertEqual(
            models.Option_Outbreak_Case.objects.filter(name='测试').count(),
            1)

    def test_option_added_with_return_id(self):
        res = post(ajax.update_option, {
            'option_type': 'Option_Outbreak_Case',
            'name': 'test'
        })

        self.assertIsNotNone(res)

    def test_random_option_delete(self):
        id = models.Option_Outbreak_Case.objects.create(name="test").id
        post(ajax.delete_option, {
            'option_type': 'Option_Outbreak_Case',
            'id': id
        })

        self.assertEqual(
            models.Option_Outbreak_Case.objects.all().count(),
            3
        )


minimal_patient = {"patient_name": "test", "birth_date": '2016-08-09',
                   "ethic_group": 2, "gender": models.Patient.MALE,
                   "outbreak_age": 23}


def format_patient_id(date, num):
    return "{:%Y%m%d}{:04d}".format(date, num)


class PatientInfoTests(TestCase):
    @classmethod
    def setUpClass(cls):
        models.Option_Similar_Disease.objects.create(name="test1")
        models.Option_Similar_Disease.objects.create(name="test2")
        models.Option_Similar_Disease.objects.create(name="test3")
        models.Option_Similar_Disease.objects.create(name="test4")

    @classmethod
    def tearDownClass(cls):
        models.Option_Similar_Disease.objects.all().delete()

    def setUp(self):
        self.patient = models.Patient.objects.create(**{
            'patient_name': 'test',
            'birth_date': '2015-12-03',
            'ethic_group': 2,
            'gender': True,
            'outbreak_age': 12
        })

    def tearDown(self):
        models.Patient.objects.all().delete()
        self.patient = None

    def test_add_patient_will_return_new_id(self):
        res = post_json(ajax.update_model, {
            'model_name': 'Patient',
            'data': minimal_patient
        })

        self.assertEqual(len(res), 12)

    def test_add_patient_will_increase_object_count(self):
        post_json(ajax.update_model, {
            'model_name': 'Patient',
            'data': minimal_patient
        })

        num = models.Patient.objects.count()
        self.assertEqual(
            num, 2
        )

    def test_delete_will_return_deleted_patient_id(self):
        id = post(ajax.delete_model, {
            'id': self.patient.id,
            'model': 'Patient'
        })

        self.assertEqual(id, self.patient.id)

    def test_delete_will_decrease_patient_num(self):
        id = post(ajax.delete_model, {
            'id': self.patient.id,
            'model': 'Patient'
        })

        num = models.Patient.objects.count()

        self.assertEqual(num, 0)



class AjaxUtils(TestCase):
    def test_is_option_model_return_false_on_Option_base_clase(self):
        self.assertFalse(util.is_option_model(models.Option))

    def test_is_option_model_return_true_on_option_models(self):
        self.assertTrue(util.is_option_model(models.Option_Similar_Disease))

    def test_is_option_model_return_false_on_non_option_models(self):
        self.assertFalse(util.is_option_model(models.Patient))


class BackupTest(TestCase):
    object_id = None
    backup_id = None

    @classmethod
    def setUpClass(cls):
        cls.object_id = models.Patient.objects.create(**minimal_patient).id
        cls.backup_id = models.Backup.objects.create(**{
            "model": "Patient",
            "field": "name",
            "content": "hahahah",
            "object_id": cls.object_id
        }).id


    @classmethod
    def tearDownClass(cls):
        models.Patient.objects.filter(id=cls.object_id).delete()

    def test_create_new_backup_exist_in_database(self):
        res = post(ajax.update_backup, {
            "model": "Patient",
            "field": "what",
            "content": "test",
            "object_id": type(self).object_id
        })

        database_entry = models.Backup.objects.filter(id=res)
        self.assertEqual(database_entry.count(), 1)

    def test_get_backup_from_database(self):
        backup = post(ajax.get_backup, {
            "model": "Patient", "field": "name", "object_id": type(self).object_id
        })
        self.assertEqual(backup, [{
            "id": type(self).backup_id,
            "model": "Patient",
            "field": "name",
            "content": "hahahah",
            "object_id": type(self).object_id
        }])

    def test_get_backup_by_id(self):
        res = post(ajax.get_backup_by_id, {
            "object_id": type(self).object_id
        })
        self.assertEqual(res, [{
            "id": type(self).backup_id,
            "model": "Patient",
            "field": "name",
            "content": "hahahah",
            "object_id": type(self).object_id
        }])

    def test_delete_backup_from_database(self):
        id = post(ajax.delete_backup, {'id': type(self).backup_id})
        self.assertEqual(int(id), type(self).backup_id)
