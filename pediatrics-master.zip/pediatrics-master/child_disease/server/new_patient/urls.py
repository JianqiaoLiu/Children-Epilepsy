from django.conf.urls import url
from .views import index
from . import ajax
import inspect


def mapToAjax(module):
    pattern = []
    for name in dir(ajax):
        attr = getattr(module, name)
        if callable(attr) and not inspect.isclass(attr):
             pattern.append(url(r'^ajax/{}$'.format(name), attr))

    return pattern


urlpatterns = mapToAjax(ajax)
urlpatterns += [
    url(r'^.*$', index)
]
