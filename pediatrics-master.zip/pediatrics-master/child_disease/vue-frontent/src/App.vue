<template>
  <top-navigator></top-navigator>
  <alert
    :show.sync="alert"
    :duration="2000"
    :type="error ? 'danger' : (success ? 'success' : null)"
    width="300px"
    placement="top-right"
    dismissable>{{message}}</alert>
  <div
    class="container"
  >
    <div class="row">
      <div class="col-md-12">
        <router-view
          v-if="dataReady"
        ></router-view>
      </div>
    </div>
  </div>
</template>

<script>
import TopNavigator from './components/TopNavigator'
import {alert} from 'vue-strap'
import ajax from './util/ajax'
import store from './store'
import glossary from './config/glossary'

export default {
  components: {
    TopNavigator,
    alert
  },
  data: function () {
    return {
      store,
      alert: false,
      error: false,
      success: false,
      message: null,
      dataReady: false
    }
  },
  /**
   * Get meta data from server, also load glossary from config file
   * @return {undefined} return nothing
   */
  beforeCompile: function () {
    ajax('/ajax/initialize')
      .then((res) => {
        this.store.models.setMetas(res.meta)
        this.store.verbose = {
          ...res.verbose,
          ...glossary
        }
        this.dataReady = true
      })
  },

  events: {
    'fail-act' (msg) {
      this.alert = true
      this.error = true
      this.success = false
      this.message = msg
    },
    'success-act' () {
      this.alert = true
      this.error = false
      this.success = true
      this.message = '操作成功'
    }
  }
}
</script>

<style lang="scss">
$icon-font-path: "../node_modules/bootstrap-sass/assets/fonts/bootstrap/";
$body-bg: #f8f8f8;

$panel-border-radius: 0;

@import '../node_modules/bootstrap-sass/assets/stylesheets/_bootstrap';


</style>
