<template>
<div class="row">
  <div class="col-md-offset-6 col-md-6">
    <div class="input-group input-group-sm">
      <div class="input-group-addon">
        添加新选项
      </div>
      <input
        type="text"
        class="form-control"
        v-model="newValue"
        @keypress="press"
      >
      <div class="input-group-btn">
        <button
          class="btn btn-success"
          @click="add"><span class="glyphicon glyphicon-plus"></span></button>
      </div>
    </div>
  </div>
  <div class="col-md-12">
    <partial name="table"></partial>
  </div>
</div>
</template>

<script type="text/javascript">
import table from '../mixin/table'

export default {
  mixins: [table],
  data () {
    return {
      newValue: ''
    }
  },
  methods: {
    add () {
      this.$dispatch('addable-table-add', {name: this.name, newValue: this.newValue})
    },
    press (e) {
      if (e.keyCode === 13) {
        this.add()
      }
    }
  }
}
</script>
