<template>
<div
  v-el:annotate
  v-show="show"
  transition="annotate"
  class="annotate hidden-print"
  @mouseenter="handleAnnotateMouseenter"
  @mouseleave="handleAnnotateMouseleave"
>
  <div
    v-if="expanded"
    class="form"
  >
    <textarea
      class="form-control"
      @focus="handleFocus"
      @blur="handleBlur"
      v-model="editContent"
    ></textarea>
    <button
      v-if="!prestine"
      class="btn btn-success btn-xs"
      @click="save"
    >保存</button>
    <button
      v-if="!prestine"
      class="btn btn-primary btn-xs"
      @click="reset"
    >重置</button>
    <button
      class="btn btn-danger btn-xs"
      @click="delete"
    >删除</button>
  </div>
  <button
    v-if="!expanded"
    class="add btn btn-success btn-xs"
    @click="create"
  ><span class="glyphicon glyphicon-plus"></span></button>
</div>
<span
  v-el:master
  @mouseenter="handleMouseenter | debounce 50"
  @mouseleave="handleMouseleave | debounce 50"
>
  <slot></slot>
</span>
</template>

<script type="text/javascript">
import unitFormControl from './UnitFormControl'
import resetable from './resetable'
import ajax from '../util/ajax'

/**
 * annotation is a component that have direct access to store
 */
export default {
  mixins: [resetable('content', {editingDataName: 'editContent'})],
  components: {
    unitFormControl
  },
  data () {
    return {
      annotates: this.$root.store.annotates,
      masterHover: false,
      annotateHover: false,
      focus: false,
      expanded: false,
      // content that take from store
      content: null,
      id: null,
      // the content to be edit
      editContent: null,
      position: {
        top: 0,
        left: 0
      }
    }
  },
  // these are filter for loading annotate
  props: {
    field: {
      type: String,
      required: true
    },
    model: {
      type: String,
      required: true
    }
  },

  computed: {
    // now we get objectId from router. though it's a bad idea
    // TODO: change objectId data source
    objectId () {
      return this.$route.params.recordId || this.$route.params.patientId
    },
    show () {
      return this.focus || this.annotateHover || this.masterHover
    },
    expanded () {
      return this.content !== null
    }
  },
  beforeCompile () {
    const annotate = this.annotates.getAnnotate(this.model, this.field, this.objectId)
    this.content = annotate.content || null
  },
  // fisrt place the object
  ready () {
    this.computePosition()
  },
  watch: {
    // if the expanded flag change, recalculate
    expanded () {
      this.computePosition()
    },
    // Everytime one of these three data change, we need to fetch annotate from store
    'objectId' () {
      const annotate = this.annotates.getAnnotate(this.model, this.field, this.objectId)
      this.content = annotate.content || null
    },
    'field' () {
      const annotate = this.annotates.getAnnotate(this.model, this.field, this.objectId)
      this.content = annotate.content || null
    },
    'model' () {
      const annotate = this.annotates.getAnnotate(this.model, this.field, this.objectId)
      this.content = annotate.content || null
    }
  },
  methods: {
    create () {
      this.content = ''
    },
    save () {
      const annotate = {
        content: this.editContent,
        id: this.id,
        object_id: this.objectId,
        model: this.model,
        field: this.field
      }
      ajax('/ajax/update_backup', annotate).then(id => {
        this.update(this.editContent)
        this.annotates.setAnnotate(annotate)
      })
    },
    delete () {
      if (this.id) {
        ajax('/ajax/delete_backup', {id: this.id})
        .then((deleteNum) => {
          this.annotates.deleteAnnotate()
          this.update(null)
          this.$nextTick(this.handleAnnotateMouseleave)
        })
      } else {
        this.update(null)
        this.$nextTick(this.handleAnnotateMouseleave)
      }
    },

    handleMouseenter () {
      this.masterHover = true
    },
    handleMouseleave () {
      this.masterHover = false
    },
    handleAnnotateMouseenter () {
      this.annotateHover = true
    },
    handleAnnotateMouseleave () {
      this.annotateHover = false
    },
    handleFocus () {
      this.focus = true
    },
    handleBlur () {
      this.focus = false
    },

    computePosition () {
      const master = this.$els.master.children[0]
      const annotate = this.$els.annotate

      // force display to be true so that dimension can be retrieved
      this.focus = true

      this.$nextTick(() => {
        this.position.left = master.offsetLeft - annotate.offsetWidth
        this.position.top = master.offsetTop

        annotate.style.top = this.position.top + 'px'
        annotate.style.left = this.position.left + 'px'

        this.focus = false
      })
    }
  }
}
</script>
<style lang="scss">
.annotate {
  position: absolute;
  z-index: 999;
  padding: 5px 6px;
  background: #444;
  border-radius: 5px 0px 5px 5px;
  box-shadow: 0px 2px 5px rgba(0,0,0, .3);

  &:after {
    content: ' ';
    display: block;
    position: absolute;
    right: -20px;
    top: 0;
    border: 10px solid transparent;
    border-left: 10px solid #444;
  }

  textarea {
    width: 200px;
    height: 100px;
    background: none;
    border: 0;
    color: #fff;
    &:focus {
      outline: 0;
      box-shadow: none;
    }
  }

  .btn {
    margin-right: 2px;
  }
}
.annotate-transition {
  transform: translate3d(-20px, 0, 0);
}
.annotate-enter, .annotate-leave {
  opacity: 0;
  transform: translate3d(100px, 0, 0);
}
</style>
