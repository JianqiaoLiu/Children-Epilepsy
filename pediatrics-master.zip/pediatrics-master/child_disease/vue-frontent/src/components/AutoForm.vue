<template>
<div class="row">
  <div class="col-md-6" v-for="field in fieldMeta">
    <annotation
      :field="field.name"
      :model="model"
    >
    <unit-form-control
        :label="field.name | verbose"
        :data.sync="data[field.name]"
        :field-meta="field"
        :validation="!prestine"
        ></unit-form-control>
    </annotation>
  </div>
</div>
<div class="form-group" style="height: 40px">
  <button
    v-if="!prestine"
    class="btn"
    :class="{'btn-success': !submitting, 'btn-disable': submitting}"
    @click="submit">提交修改</button>
  <button
    v-if="!prestine"
    class="btn btn-primary"
    style="margin-left: 10px"
    @click="reset">撤销修改</button>
</div>
</template>

<script>
import fieldMeta from '../util/fieldMeta'
import unitFormControl from './UnitFormControl'
import annotation from './Annotation'
import resetable from './resetable'
import sortBy from 'lodash/sortBy'
import cloneDeep from 'lodash/cloneDeep'
import mapValues from 'lodash/mapValues'

export default {
  mixins: [resetable('data')],
  components: {
    unitFormControl,
    annotation
  },

  data () {
    return {
      submitting: false
    }
  },
  // formData for initial form data
  // meta   for field meta info
  // title  the title of the form
  props: {
    'data': {
      type: Object,
      required: true,
      coerce (val) {
        // make sure the data is a clone version
        // so changes made to the data in the form
        // have nothing todo with data passed here
        return cloneDeep(val)
      }
    },
    'meta': {
      type: Object,
      required: true
    },
    // model name to locate backup
    'model': {
      type: String,
      required: true
    }
  },

  computed: {
    fieldMeta () {
      return sortBy(mapValues(this.meta, fieldMeta), 'order')
    }
  },

  methods: {
    submit () {
      this.$dispatch('auto-form-submit', {modelName: this.model, data: this.data})
    }
  }
}
</script>
