<template>
<div
  :id='model'
  class="row model-row"
  v-for="model in visibleModels"
>
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title">{{model | verbose}}</h3>
      </div>
      <div class="panel-body">
        <auto-form
          :data="data[model]"
          :meta="models.items[model]"
          :model="model"
        ></auto-form>
      </div>
    </div>
  </div>
</div>
</template>

<script>
import AutoForm from './AutoForm'

export default {
  components: {
    AutoForm
  },
  data () {
    return {
      models: this.$root.store.models
    }
  },
  props: {
    data: {
      type: Object,
      required: true
    },
    visibleModels: {
      type: Array,
      required: true
    }
  },
  methods: {
    remove (model, index) {
      if (index !== 0) {
        this.$dispatch('edit-delete', {model, index})
      }
    }
  }
}
</script>
