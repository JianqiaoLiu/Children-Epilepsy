<template>
<partial name="table"></partial>
</template>
<script>
import table from '../mixin/table'
export default {
  mixins: [table]
}
</script>
<style lang="scss">
table button {
  margin-right: 10px;
}
</style>
