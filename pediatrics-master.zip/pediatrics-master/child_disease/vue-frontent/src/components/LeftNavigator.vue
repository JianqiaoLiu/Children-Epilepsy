<template>
<ul class="nav nav-pills nav-stacked hidden-print">
  <li
    v-for="m in menu | limitBy limit"
    v-link-active
  >
    <a
      v-link="normalizeLink(m.link)"
    >{{m.name}}</a>
  </li>
</ul>
</template>

<script>
export default {
  props: {
    menu: {
      type: Array,
      required: true
    },
    limit: {
      type: Number,
      default: () => { 10 }
    }
  },
  methods: {
    normalizeLink (link) {
      if (typeof link === 'string') {
        return {
          path: link,
          activeClass: 'active',
          exact: true
        }
      } else {
        return Object.assign(link, {activeClass: 'active', exact: true})
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.nav {
  padding: 5px 0;
  margin-bottom: 10px;
  li {
    margin: 0;
    &.active {
      border-color: #337ab7;
    }
  }
  a {
    border-radius: 0;
  }
}
</style>
