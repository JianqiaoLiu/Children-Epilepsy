<template>
<div class="row">
  <div class="col-md-10">
    <slot></slot>
  </div>
  <div class="col-md-2 hidden-print">
    <affix
      :offset="100"
    >
      <ul class="nav nav-stacked">
        <li
          v-for="model in models"
        ><a
          v-link="path + '#' + model"
          @click="scroll(model)">{{model | verbose}}
        </a></li>
      </ul>
    </affix>
  </div>
</div>
</template>

<script type="text/javascript">
import {affix} from 'vue-strap'

export default {
  components: {
    affix
  },
  props: {
    models: {
      type: Array,
      required: true
    }
  },
  computed: {
    path () {
      return this.$route.path
    }
  },
  methods: {
    scroll (id) {
      const top = document.getElementById(id).getBoundingClientRect().top
      const scrollY = top + window.scrollY
      window.scrollTo(0, scrollY)
    }
  }
}
</script>
