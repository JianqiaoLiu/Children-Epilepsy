<template>
<ul class="pagination" v-if="numPages > 0">
  <li>
    <a @click="prev" aria-label="Previous">
      <span aria-hidden="true">&laquo;</span>
    </a>
  </li>
  <li
    :class="{'active': num + 1 === currentPage}"
    v-for="num in numActualPages"
  ><a @click="page(num + 1)">{{num + 1}}</a></li>
  <li>
    <a @click="next" aria-label="Next">
      <span aria-hidden="true">&raquo;</span>
    </a>
  </li>
</ul>
</template>

<script>
/**
 * page index start a 1
 */
export default {
  props: {
    numPages: {
      type: Number,
      default: 1
    },
    numVisiblePages: {
      type: Number,
      default: 10
    },
    startPage: {
      type: Number,
      default: 1
    }
  },

  computed: {
    numActualPages () {
      return Math.min(this.numPages, this.numVisiblePages)
    },
    overMax () {
      return this.numPages > this.numVisiblePages
    }
  },

  data () {
    return {
      currentPage: 1
    }
  },

  methods: {
    prev () {
      this.currentPage = Math.max(this.currentPage - 1, 1)
      this.$dispatch('pagination-change', this.currentPage)
    },
    next () {
      this.currentPage = Math.min(this.currentPage + 1, this.numPages)
      this.$dispatch('pagination-change', this.currentPage)
    },
    page (num) {
      if (num <= this.numPages || num >= 1) {
        this.currentPage = num
        this.$dispatch('pagination-change', this.currentPage)
      }
    }
  }
}
</script>

<style lang="scss">
.pagination a {
  cursor: pointer;
}
</style>
