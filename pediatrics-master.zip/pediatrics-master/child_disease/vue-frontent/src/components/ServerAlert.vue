<template>
<alert :type='state ? "success" : "danger"'>
  {{message}}
</alert>
</template>

<script>
import {alert} from 'vue-strap'

export default {
  components: {
    alert
  },


}
</script>
