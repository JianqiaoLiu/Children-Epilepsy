<template>
  <div role="tabpanel" class="tab-pane"
      :class="{hide:!show}"
      v-show="show"
      :transition="transition"
  >
    <slot></slot>
  </div>
</template>

<script>
  export default {
    props: {
      header: {
        type: String
      },
      disabled: {
        type: Boolean,
        default: false
      }
    },
    data () {
      return {
        index: 0
      }
    },
    computed: {
      show () {
        return this.$parent.activeIndex === parseInt(this.index)
      },
      transition () {
        return this.$parent.effect
      }
    },
    created () {
      this.$parent.renderData.push({
        header: this.header,
        disabled: this.disabled
      })
    },
    ready () {
      for (let c in this.$parent.$children) {
        if (this.$parent.$children[c].$el === this.$el) {
          this.index = c
          break
        }
      }
    },
    detached () {
      this.$parent.renderData.splice(this.index, 1)
    }
  }
</script>

<style scoped>
  .tab-content > .tab-pane {
    display: block
  }
</style>
