<template>
<svg xmlns="http://www.w3.org/2000/svg"
  v-el:canvas
  @mousedown="dragStart"
  @mouseup="dragging = false"
  @mouseleave="dragging = false"
  @mousemove="drag"
  :width="canvasWidth"
  :height="canvasHeight">
  <!-- draw axis -->
  <g class="axis x">
    <line
      :stroke="axisColor"
      x1="0" :y1="canvasHeight - 20"
      :x2="canvasWidth" :y2="canvasHeight - 20"
    ></line>
  </g>
  <g
    class="time"
    :transform="'translate(' + scrollX + ')'"
    v-el:viewbox>
    <g class="node"
      @click="$dispatch('timeline-node-click', node.id)"
      @mouseenter="node.active = true"
      @mouseleave="node.active = false"
      :transform="'translate(' + calX(node.startTime) + ',' + (node.track * (barSize + gapSize)) + ')'"
      v-for="node in data">
      <rect
        :fill="node.active ? secondColor : mainColor"
        :width="calX(node.endTime || new Date()) - calX(node.startTime)"
        :height="barSize"
      ></rect>
      <text x="5" y="15" fill="#fff">{{node.label}}</text>
    </g>
    <g class="axis-text">
      <text
        v-for="m in range"
        :x="m * monthRatio" :y="canvasHeight - 3"
      >{{(earliest.getMonth() + m) % 12  + 1}}月</text>
    </g>
  </g>
</svg>
</template>

<script>
export default {
  props: {
    data: {
      type: Array,
      required: true,
      coerce (value) {
        const newValue = value.map(v => {
          return {
            ...v,
            // if the bar is active(mouse hover)
            active: false,
            // which track the bar at
            track: 0
          }
        })

        newValue.forEach(v => {
          let overlap = []

          // find overlap intervals
          newValue.forEach(_v => {
            if (_v === v) {
              return
            }
            if (
              !(v.endTime < _v.startTime && v.endTime < _v.endTime) &&
              !(v.startTime > _v.startTime && v.startTime > _v.endTime)
            ) {
              overlap.push(_v.track)
            }
          })

          let track = 0
          for (let num = 0; num < 5; num++) {
            if (overlap.indexOf(num) === -1) {
              track = num
              break
            }
          }
          v.track = track
        })

        return newValue
      }
    }
  },
  data () {
    return {
      axisColor: '#aaa',
      canvasWidth: '100%',
      canvasHeight: 300,

      scrollX: 0,
      dragging: false,
      dragStartPoint: 0,
      dragStartScrollX: 0,

      barSize: 40,
      gapSize: 5,
      dayRatio: 8,
      mainColor: '#FFA726',
      secondColor: '#F57C00'
    }
  },
  ready () {
    const canvasWidth = this.$els.canvas.clientWidth
    const viewboxWidth = this.$els.viewbox.getBoundingClientRect().width
    this.canvasWidth = canvasWidth
    this.scrollX = canvasWidth - viewboxWidth
  },
  computed: {
    monthRatio () {
      return this.dayRatio * 31
    },
    earliest () {
      const now = new Date()
      let earliest = now
      for (let node of this.data) {
        if (node.startTime < earliest) {
          earliest = node.startTime
        }
      }
      return earliest
    },
    // find the month range
    range () {
      return Math.ceil((new Date() - this.earliest) / (1000 * 3600 * 24 * 30))
    }
  },
  methods: {
    diffMonth (a, b) {
      let months
      months = (b.getFullYear() - a.getFullYear()) * 12
      months -= a.getMonth()
      months += b.getMonth()
      return months <= 0 ? 0 : months
    },
    calX (startTime) {
      return this.diffMonth(this.earliest, startTime) *
        this.monthRatio +
        (startTime.getDate() - 1) *
        this.dayRatio
    },
    drag (e) {
      if (this.dragging) {
        const canvasWidth = this.$els.canvas.clientWidth
        const viewboxWidth = this.$els.viewbox.getBoundingClientRect().width
        const dragBoundingLeft = 20
        const dragBoundingRight = canvasWidth - viewboxWidth - 20

        const nextScrollX = this.dragStartScrollX + e.clientX - this.dragStartPoint
        if (nextScrollX <= dragBoundingRight) {
          this.scrollX = dragBoundingRight
        } else if (nextScrollX >= dragBoundingLeft) {
          this.scrollX = dragBoundingLeft
        } else {
          this.scrollX = nextScrollX
        }
      }
    },
    dragStart (e) {
      this.dragStartPoint = e.clientX
      this.dragStartScrollX = this.scrollX
      this.dragging = true
    }
  }
}
</script>

<style scoped lang="scss">
.node {
  cursor: pointer;
}
</style>
