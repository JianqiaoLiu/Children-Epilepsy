<template>
<nav class="navbar navbar-default hidden-print">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
      <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <span class="navbar-brand">儿童癫痫症信息</span>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li
              v-link-active
              v-for="menu in menus"
            >
              <a v-link="menu.link">{{menu.name}}</a>
            </li>
          </ul>
          <button
            type="button"
            class="btn btn-success navbar-btn navbar-right"
            v-link="{name: 'patient', params: {patientId: 0}, query: {mode: 'edit'}}"
          ><span class="glyphicon glyphicon-plus" aria-hidden="true"></span>添加病人</button>
        </div><!-- /.navbar-collapse -->
      </div>
    </div>
  </div><!-- /.container-fluid -->
</nav>
</template>

<script>
export default {
  data: () => {
    return {
      test: 'shit',
      menus: [
        {name: '搜索', link: {path: '/search', activeClass: 'active'}},
        {name: '设置', link: {path: '/setting', activeClass: 'active'}}
      ]
    }
  }
}
</script>

<style lang="scss">
.navbar {
  z-index: 1;
  border-bottom: 0;
  .nav li a:focus {
    background: none !important;
  }
  .nav li.active a{
    background: none;
    font-weight: bold;
    transform: translateY(-2px);
  }
}
</style>
