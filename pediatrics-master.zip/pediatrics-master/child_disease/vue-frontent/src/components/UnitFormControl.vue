<template>
  <div class="form-group" :class="{'has-error': error}">
    <label
      class="control-label"
      for="name"
    >{{label}}</label>
    <tooltip
      v-if="fieldMeta.help_text"
      placement="right"
      :content="fieldMeta.help_text"
    >
      <i class="glyphicon glyphicon-question-sign help"></i>
    </tooltip>
    <textarea
      class="form-control"
      rows="5"
      v-if="fieldMeta.type === 'textarea'"
      v-model="data"
    >
    </textarea>
    <select
      class="form-control"
      v-if="fieldMeta.type === 'select' || fieldMeta.type === 'multiple'"
      :multiple="fieldMeta.type === 'multiple'"
      v-model="data"
    >
      <option
        v-for="choice in fieldMeta.choices"
        :value="choice.id"
      >{{choice.name}}</option>
    </select>
    <input
      v-if="!fieldMeta.suffix && isNormalType(fieldMeta.type)"
      :type="fieldMeta.type"
      :name="fieldMeta.name"
      v-model="data"
      :disabled="fieldMeta.auto"
      class="form-control"
      :number="fieldMeta.type === 'number'"
      @keypress="handleKeyPress">
    <div
      v-if="fieldMeta.suffix"
      class="input-group">
      <input
        v-if="isNormalType(fieldMeta.type)"
        :type="fieldMeta.type"
        :name="fieldMeta.name"
        v-model="data"
        :disabled="fieldMeta.auto"
        class="form-control"
        :number="fieldMeta.type === 'number'"
        @keypress="handleKeyPress">
      <span class="input-group-addon">{{fieldMeta.suffix}}</span>
    </div>
    <p class="help-block" :class="{'show': error}">
      {{message}}&nbsp;
    </p>
  </div>
</template>

<script>
// Tasks:
// 1. Basic form control function
// 2. velidation and error message display.
//    velidation and error message need to be customizable.
// 3. description on the control
// 4. placeholder displaying
// 5. unified type. e.g. <select> and <input> and <textarea> should be unified.
//    using type attribute to determine actual type
// 6. field.suffix string
import {tooltip} from 'vue-strap'

const abnormalType = ['select', 'textarea', 'multiple']
export default {
  components: {
    tooltip
  },
  data () {
    return {
      message: null
    }
  },
  props: {
    label: {
      type: String,
      default: ''
    },
    data: {
      required: true,
      twoWay: true
    },
    fieldMeta: {
      type: Object,
      required: true
    },
    validation: {
      type: Boolean,
      default: true
    }
  },

  computed: {
    error () {
      const {max_length, auto, nullable, type} = this.fieldMeta
      if (this.validation) {
        // max length check
        if (max_length && this.data && this.data.length > max_length) {
          this.message = '内容过长'
          return true
        }
        // null check
        if (!auto && !nullable && this.data === null) {
          this.message = '不能为空'
          return true
        }
        // number check
        if (type === 'number' && !isNumber(this.data)) {
          this.message = '这里需要填写数字'
          return true
        }
      }
      return false
    }
  },

  methods: {
    handleKeyPress (e) {
      this.$dispatch('keypress', e)
    },
    isNormalType (type) {
      return abnormalType.indexOf(type) === -1
    }
  }
}

function isNumber (val) {
  return typeof val === 'number'
}
</script>

<style lang="scss" scoped>
.help {
  vertical-align: top;
  cursor: pointer;
  color: #999;
  &:hover {
    color: #666;
  }
}
.help-block {
  opacity: 0;
  &.show {
    opacity: 1;
  }
}
</style>
