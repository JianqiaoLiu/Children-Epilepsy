<template>
<div
  :id='model'
  class="row model-row"
  v-for="model in visibleModels"
>
  <div class="col-md-12">
    <div class="panel panel-default hidden-print">
      <div class="panel-heading">
        <h3 class="panel-title">{{model | verbose}}</h3>
      </div>
      <!-- multiple model. e.g. Medication -->
      <div
        class="panel-body"
        v-if="isArray(data[model])"
        v-for="d in data[model]"
      >
        <div
          class="row"
        >
          <div
            class="col-md-4 col-xs-6 col-sm-4"
            v-for="field in models.items[model]"
          >
            <label class="view-label">{{field.name | verbose}}:</label>
            <span>{{d[field.name] | verbose model field.name}}</span>
          </div>
        </div>
      </div>
      <!-- single model -->
      <div class="panel-body">
        <div
          v-if="!isArray(data[model])"
          class="row"
        >
          <div
            class="col-md-4 col-xs-6 col-sm-4"
            v-for="field in models.items[model]"
          >
            <label class="view-label">{{field.name | verbose}} :</label>
            <span>{{data[model][field.name] | verbose model field.name}}</span>
          </div>
        </div>
      </div>
    </div>
    <!-- for printing  -->
    <!-- multiple model. e.g. Medication -->
    <div
      class="row visible-print-block"
      v-if="isArray(data[model])"
      v-for="d in data[model]"
    >
      <div class="col-xs-12">
        <h3>{{model | verbose}}</h3>
      </div>
      <div
        class="col-xs-4"
        v-for="field in models.items[model]"
      >
        <label class="view-label">{{field.name | verbose}}:</label>
        <span>{{d[field.name] | verbose model field.name}}</span>
      </div>
    </div>
    <!-- single model -->
    <div
      v-if="!isArray(data[model])"
      class="row visible-print-block"
    >
      <div class="col-xs-12">
        <h3>{{model | verbose}}</h3>
      </div>
      <div
        class="col-xs-4 visible-print-block"
        v-for="field in models.items[model]"
      >
        <label class="view-label">{{field.name | verbose}} :</label>
        <span>{{data[model][field.name] | verbose model field.name}}</span>
      </div>
    </div>
  </div>
</div>
</template>
<script>
import {tooltip} from 'vue-strap'
export default {
  components: {
    tooltip
  },
  data () {
    return {
      models: this.$root.store.models
    }
  },
  props: {
    data: {
      type: Object,
      required: true
    },
    visibleModels: {
      type: Array,
      required: true
    }
  },
  methods: {
    isArray: Array.isArray,
    min: Math.min
  }
}
</script>

<style media="screen">
.view-label {
  color: #333;
  margin-right: 5px;
}
</style>
