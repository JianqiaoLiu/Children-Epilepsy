import cloneDeep from 'lodash/cloneDeep'
import isEqual from 'lodash/isEqual'

function factory (initialDataName, options) {
  const editingDataName = options && options.editingDataName
  return {
    data () {
      return {
        backupData: null
      }
    },
    props: {
      batchRetset: {
        type: Boolean,
        default: () => false
      }
    },
    computed: {
      prestine () {
        if (editingDataName) {
          return isEqual(this.backupData, this[editingDataName])
        } else {
          return isEqual(this.backupData, this[initialDataName])
        }
      },
      dirty () {
        return !this.prestine
      }
    },
    methods: {
      reset () {
        if (editingDataName) {
          this[editingDataName] = cloneDeep(this.backupData)
        } else {
          this[initialDataName] = cloneDeep(this.backupData)
        }
      },

      update (newData) {
        this.backupData = cloneDeep(newData)
        this[initialDataName] = cloneDeep(newData)
        this[editingDataName] = newData
      }
    },
    events: {
      'resetable-reset' () {
        this.reset()
      },
      'resetable-update' () {
        this.update(this[initialDataName])
      }
    },
    watch: {
      [initialDataName] () {
        this.backupData = cloneDeep(this[initialDataName])
        if (editingDataName) {
          this[editingDataName] = cloneDeep(this[initialDataName])
        }
      }
    },
    beforeCompile () {
      this.backupData = cloneDeep(this[initialDataName])
      if (editingDataName) {
        this[editingDataName] = cloneDeep(this[initialDataName])
      }
    }
  }
}
export default factory
