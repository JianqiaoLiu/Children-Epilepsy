export default {
  'num_records': '诊疗记录数',
  'age': '年龄'
}
