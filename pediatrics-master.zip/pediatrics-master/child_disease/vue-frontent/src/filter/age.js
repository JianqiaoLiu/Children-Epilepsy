export default function (dateStr) {
  const date = new Date(dateStr)
  const now = new Date()
  return now.getYear() - date.getYear()
}
