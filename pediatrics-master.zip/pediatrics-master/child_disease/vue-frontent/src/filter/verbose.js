import store from '../store'
export default function (...args) {
  if (args.length === 1) {
    const arg = args[0]
    if (typeof arg === 'boolean') {
      return booleanVerbose(...args)
    } else {
      return metaVerbose(...args)
    }
  } else if (args.length === 3) {
    return choiceVerbose(...args)
  }
}

/**
 * tranform field/model name to its verbose name
 * @param  {String} name  field/model name
 * @return {String}       verbose name
 */
function metaVerbose (name) {
  return store.verbose[name] || name
}

/**
 * transform choice value to its verbose name
 * @param  {Any} value      the value
 * @param  {String} modelName model name for locating
 * @param  {String} fieldName field name for locating
 * @return {String}           verbose name
 */
function choiceVerbose (values, modelName, fieldName) {
  const field = store.models.items[modelName] &&
    store.models.items[modelName][fieldName]
  if (!field) {
    return values
  }
  if (
    field.choices.length > 0 ||
    field.django_type.indexOf('Boolean') !== -1
  ) {
    if (!Array.isArray(values)) {
      values = [values]
    }
    const names = values.map((value) => {
      const choice = field.choices.find((choice) => {
        return choice.id === value
      })
      return choice && choice.name
    })
    return names.join(',')
  }
  return values
}

/**
 * tranform boolean value to string
 * @param  {Boolean} value boolean value
 * @return {String}       verbose
 */
function booleanVerbose (value) {
  return value ? '有' : '无'
}
