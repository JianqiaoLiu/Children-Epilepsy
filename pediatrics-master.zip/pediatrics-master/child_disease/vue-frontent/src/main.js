import Vue from 'vue'
import App from './App'

import VueRouter from 'vue-router'

import verbose from './filter/verbose'
import age from './filter/age'

import Search from './pages/Search'
import Setting from './pages/Setting'
import Option from './pages/Option'
import Patient from './pages/Patient'
// import Analysis from './pages/Analysis'
import Record from './pages/Record'
import RecordList from './pages/RecordList'
import PatientInfo from './pages/PatientInfo'
import Medication from './pages/Medication'

Vue.use(VueRouter)
Vue.filter('verbose', verbose)
Vue.filter('age', age)
// Vue.config.debug = true

/* eslint-disable no-new */

const router = new VueRouter({history: true})

router.map({
  '/': {
    component: Search
  },
  '/search': {
    component: Search
  },
  '/setting': {
    component: Setting,
    subRoutes: {
      '/option': {
        component: Option
      }
    }
  },
  '/patient/:patientId': {
    name: 'patient',
    component: Patient,
    subRoutes: {
      '/': {
        component: PatientInfo
      },
      '/record': {
        name: 'recordList',
        component: RecordList
      },
      '/record/:recordId': {
        name: 'record',
        component: Record
      },
      '/medication': {
        name: 'medication',
        component: Medication
      }
    }
  }
})

router.start(App, '#root')
