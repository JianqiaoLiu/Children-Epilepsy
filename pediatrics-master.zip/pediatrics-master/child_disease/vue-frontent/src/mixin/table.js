export default {
  props: {
    // the name of the table for action discrimination
    'name': {
      type: String,
      required: true
    },
    'rows': {
      type: Array
    },
    'header': {
      type: Array
    },
    'actions': {
      type: Array
    }
  },
  methods: {
    handleAction (action, rowId) {
      this.$dispatch(`editable-table-${action}`, {name: this.name, rowId})
    }
  },
  partials: {
    table: `
      <table class="table table-hover table-condensed">
        <thead>
          <tr>
            <th v-for="col in header">
              {{col.verboseName}}
            </th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in rows">
            <td v-for="col in header">
              {{row[col.name]}}
            </td>
            <td width="200">
              <button
                class="btn btn-default btn-sm"
                v-for="action in actions"
                @click="handleAction(action.name, row.id)"
              >{{action.verboseName}}</button>
            </td>
          </tr>
        </tbody>
      </table>
    `
  }
}
