<template>
<div class='row'>
  <div class='col-md-12'>
    <h2>统计</h2>
    <hr>
  </div>
  <div class='col-md-4'>
    <p>
      病人总数: {{patientNum}}
    </p>
  </div>
  <div class='col-md-4'>
    <p>
      诊疗总数: {{recordNum}}
    </p>
  </div>
  <div class='col-md-4'>
    <p>
      脑电图总数: {{eegNum}}
    </p>
  </div>
  <div class='col-md-12'>
    <!-- <pre>
      {{gender | json}}
    </pre> -->
    <svg id='d3' v-el:canvas></svg>
  </div>
</div>
</template>
<script>
import ajax from '../util/ajax'

export default {
  data () {
    return {
      patientNum: 0,
      recordNum: 0,
      eegNum: 0,
      gender: null
    }
  },
  // integrate d3
  ready () {},
  beforeCompile () {
    Promise.all([
      ajax('/ajax/total'),
      ajax('/ajax/statistic_category', {item: 'gender'})
    ]).then(([total, gender]) => {
      this.patientNum = total.total_patients
      this.recordNum = total.total_records
      this.eegNum = total.total_eegs
      this.gender = gender
    })
  }
}
</script>
