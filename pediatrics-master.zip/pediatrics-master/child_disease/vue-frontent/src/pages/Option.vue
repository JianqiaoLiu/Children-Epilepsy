<template>
<div class="row">
  <div class="col-md-12">
    <model-viewer
      :models="visibleModels"
    >
      <div
        class="row"
        v-for="model in visibleModels"
        :id="model"
      >
        <div class="col-md-12">
          <div style="min-height: 400px" class="panel panel-default">
            <div class="panel-heading">
              <h3 class="panel-title">{{model | verbose}}</h3>
            </div>
            <div class="panel-body">
              <addable-table
                :name="model"
                :rows="values(options.items[model])"
                :header="optionHeader"
                :actions="tableActions"
              ></addable-table>
            </div>
          </div>
        </div>
      </div>
    </model-viewer>
  </div>
</div>
</template>
<script>
import LeftNavigator from '../components/LeftNavigator'
import AddableTable from '../components/AddableTable'
import ModelViewer from '../components/ModelViewer'
import ajax from '../util/ajax'
import values from 'lodash/values'

export default {
  components: {
    LeftNavigator,
    AddableTable,
    ModelViewer
  },
  data: function () {
    return {
      options: this.$root.store.options,
      models: this.$root.store.models,
      optionHeader: [
        {
          name: 'id',
          verboseName: 'id'
        },
        {
          name: 'name',
          verboseName: '选项'
        }
      ],
      tableActions: [
        {
          name: 'delete',
          verboseName: '删除'
        }
      ]
    }
  },
  computed: {
    menu () {
      return Object.keys(this.options.items).map((name) => {
        return {
          name: this.models[name].verbose_name,
          link: '/option/' + name
        }
      })
    },
    visibleModels () {
      return Object.keys(this.options.items)
    }
  },
  created: function () {
    ajax('/ajax/get_options')
      .then((res) => {
        this.options.setOptions(res)
      })
  },
  methods: {
    values,
    createOption (optionModel, newOptionName) {
      ajax('/ajax/update_option', {
        option_type: optionModel,
        name: newOptionName
      }).then((res) => {
        // successfully create option in server
        const option = {id: res, name: newOptionName}
        this.options.addOption(optionModel, res, option)
        // update models
        this.updateModels()
      })
    },

    deleteOption (optionModel, id) {
      ajax('/ajax/delete_option', {
        option_type: optionModel,
        id
      }).then((res) => {
        // successfully delete in server
        this.options.deleteOption(optionModel, res)
        // update models
        this.updateModels()
      })
    },
    // TODO: bad
    updateModels () {
      ajax('/ajax/initialize')
        .then((res) => {
          this.$root.store.models = res
        })
    }
  },
  events: {
    'editable-table-delete' (e) {
      this.deleteOption(e.name, e.rowId)
    },
    'addable-table-add' (e) {
      this.createOption(e.name, e.newValue)
    }
  }
}
</script>
