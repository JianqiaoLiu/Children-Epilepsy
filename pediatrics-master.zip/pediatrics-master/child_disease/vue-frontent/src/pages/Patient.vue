<template>
  <two-col-frame>
    <div
      slot="left"
    >
      <patient-menu></patient-menu>
      <hr>
      <button class="btn btn-danger" @click="delete">删除{{recordId ? '诊疗' : '病人'}}</button>
    </div>
    <router-view
      slot="right"
      v-if="dataReady"
    ></router-view>
  </two-col-frame>
</template>

<script>
import ajax from '../util/ajax'
import TwoColFrame from './TwoColFrame'
import patientMenu from './patientMenu'
import {createPatient} from '../util/model'

export default {
  data () {
    return {
      models: this.$root.store.models,
      records: this.$root.store.records,
      patients: this.$root.store.patients,
      annotates: this.$root.store.annotates,
      dataReady: false
    }
  },

  computed: {
    patientId () {
      return this.$route.params.patientId
    },
    recordId () {
      return this.$route.params.recordId
    },
    creating () {
      return this.patientId === '0'
    }
  },
  route: {
    /**
     * load all data of a patient
     * including patient basic, records and medication, also, annotates
     * @param  {[type]} transition [description]
     * @return {[type]}            [description]
     */
    data (transition) {
      const patientId = transition.from.params && transition.from.params.patientId
      const newPatientId = transition.to.params.patientId
      if (patientId !== newPatientId) {
        if (!this.creating) {
          Promise.all([
            ajax('/ajax/get_patient_data', {id: newPatientId}),
            ajax('/ajax/get_backup_by_patient', {patient_id: newPatientId})
          ]).then(([patient, annotates]) => {
            this.annotates.setAnnotates(annotates)
            this.$root.store.currentPatient = patient.patient
            this.$root.store.records.setRecords(patient.records)
            this.$root.store.medications.setMedications(patient.medications)
            transition.next({
              dataReady: true
            })
          })
        } else {
          // when creating new patient, we also need to load full patient empty
          // template from server
          this.$root.store.currentPatient = createPatient()
          transition.next({
            dataReady: true
          })
        }
      }
    }
  },
  methods: {
    delete () {
      if (this.recordId) {
        ajax('/ajax/delete_model', {id: this.recordId, model: 'Record'})
        .then((res) => {
          this.records.deleteRecord(this.recordId)
        })
      } else {
        ajax('/ajax/delete_model', {id: this.patientId, model: 'Patient'})
      }
    }
  },
  components: {
    patientMenu,
    TwoColFrame
  }
}
</script>
