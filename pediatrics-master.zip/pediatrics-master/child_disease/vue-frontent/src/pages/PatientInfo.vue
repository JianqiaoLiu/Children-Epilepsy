<template>
<view-edit-switch-frame
  :title="patientName + ' 病例信息'"
>
  <model-viewer
    :models="visibleModels"
    slot='edit'
  >
    <edit
      :data="patient"
      :visible-models="visibleModels"
    ></edit>
  </model-viewer>
  <model-viewer
    :models="visibleModels"
    slot='view'
  >
    <view
      :data="patient"
      :visible-models="visibleModels"
    ></view>
  </model-viewer>
</view-edit-switch-frame>
</template>

<script>
import ModelViewer from '../components/ModelViewer'
import ViewEditSwitchFrame from './ViewEditSwitchFrame'
import View from '../components/View'
import Edit from '../components/Edit'
import ajax from '../util/ajax'

const visibleModels = ['Patient', 'Family', 'Disease_History', 'Growth_History', 'Labor_History', 'Pregnant_History']

export default {
  components: {
    ModelViewer,
    View,
    Edit,
    ViewEditSwitchFrame
  },

  data () {
    return {
      models: this.$root.store.models
    }
  },
  computed: {
    patientId () {
      return this.$route.params.patientId
    },
    patientName () {
      return this.patient && this.patient.Patient && this.patient.Patient.patient_name || '新增'
    },
    creating () {
      return this.patientId === '0'
    },
    visibleModels () {
      return this.creating ? ['Patient'] : visibleModels
    },
    patient () {
      return this.$root.store.currentPatient
    }
  },
  // load patient backup from server
  events: {
    'auto-form-submit' ({modelName, data}) {
      ajax('/ajax/update_model', {model_name: modelName, data}, 'json')
      .then((id) => {
        if (this.creating) {
          this.$route.router.go({name: 'patient', params: {patientId: id}, query: {mode: 'edit'}})
        } else {
          // updating local currentpatient data if not creating
          this.$root.store.currentPatient[modelName] = data
        }
        this.$dispatch('success-act')
      }).catch((error) => this.$dispatch('fail-act', error))
    }
  }
}
</script>
