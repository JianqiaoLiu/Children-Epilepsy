<template>
<left-navigator
  :menu="patientMenu"
></left-navigator>
<left-navigator
  :menu="recordMenu"
></left-navigator>
<left-navigator
  :menu="medicationMenu"
></left-navigator>
</template>
<script>
import map from 'lodash/map'
import LeftNavigator from '../components/LeftNavigator'

export default {
  data () {
    return {
      records: this.$root.store.records,
      medications: this.$root.store.medications
    }
  },
  computed: {
    patientId () {
      return this.$route.params.patientId
    },
    recordId () {
      return this.$route.params.recordId
    },
    // left navigator menu
    patientMenu () {
      return [{
        name: '病人信息',
        link: {name: 'patient', params: {patientId: this.patientId},
        query: {mode: this.$route.query.mode || 'view'}}
      }]
    },
    recordMenu () {
      return [
        { name: '诊疗记录',
          link: {name: 'recordList', params: {patientId: this.patientId}}},
        ...map(this.records.items, record => {
          return {
            name: record.Record.date,
            link: {
              name: 'record',
              params: {patientId: this.patientId, recordId: record.Record.id},
              query: {mode: this.$route.query.mode || 'view'}
            }
          }
        })
      ]
    },
    medicationMenu () {
      return [{
        name: '用药记录',
        link: {name: 'medication', params: {
          patientId: this.patientId,
          recordId: this.recordId
        }}}
      ]
    }
  },
  components: {
    LeftNavigator
  }
}
</script>
