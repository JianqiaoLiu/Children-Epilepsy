<template>
<view-edit-switch-frame
  :title="patientName + ' ' + recordDate + ' 诊疗记录'"
>
  <model-viewer
    :models="visibleModels"
    slot='edit'
  >
    <edit
      :data="record"
      :visible-models="visibleModels"
    ></edit>
  </model-viewer>
  <model-viewer
    :models="visibleModels"
    slot='view'
  >
    <view
      :data="record"
      :visible-models="visibleModels"
    ></view>
  </model-viewer>
</view-edit-switch-frame>
</template>

<script>
import View from '../components/View'
import Edit from '../components/Edit'
import ajax from '../util/ajax'
import {createRecord} from '../util/model'
import ModelViewer from '../components/ModelViewer'
import ViewEditSwitchFrame from './ViewEditSwitchFrame'

const visibleModels = ['Record', 'Outbreak', 'Eeg', 'Ct', 'Mri', 'Prognosis']

export default {
  components: {
    ModelViewer,
    View,
    Edit,
    ViewEditSwitchFrame
  },
  data () {
    return {
      models: this.$root.store.models,
      records: this.$root.store.records,
      record: null
    }
  },

  computed: {
    visibleModels () {
      return this.creating ? ['Record'] : visibleModels
    },
    record () {
      if (this.creating) {
        return createRecord()
      } else {
        return this.$root.store.records.items[this.recordId]
      }
    },
    patient () {
      return this.$root.store.currentPatient
    },
    patientId () {
      return this.$route.params.patientId
    },
    patientName () {
      return this.patient && this.patient.Patient && this.patient.Patient.patient_name
    },
    recordId () {
      return this.$route.params.recordId
    },
    creating () {
      return !this.$root.store.records.items[this.recordId]
    },
    recordDate () {
      return this.record && this.record.Record.date
    }
  },

  events: {
    'auto-form-submit' ({modelName, data}) {
      // add record id to related model submission
      if (modelName !== 'Record') {
        data = {
          ...data,
          record: this.recordId
        }
      } else {
        // add patient id to Record model
        data = {
          ...data,
          patient: this.patientId
        }
      }

      ajax('/ajax/update_model', {
        model_name: modelName,
        data
      }, 'json')
      .then((id) => {
        // update the id no matter what
        if (this.creating) {
          data.id = id
          // go to complete record edit page after creation
          this.$route.router.go({
            name: 'record',
            params: {
              patientId: this.patientId,
              recordId: id
            },
            query: {mode: 'edit'}
          })
        }

        // update record
        this.records.updateRecord(id, {
          ...this.record,
          [modelName]: data
        })
        this.$dispatch('success-act')
      }).catch((error) => this.$dispatch('fail-act', error))
    },
    'edit-delete' ({model, index}) {
      const id = this.record[model][index].id
      ajax('/ajax/delete_model', {model, id})
      .then((res) => {
        this.records.deleteRecord(id)
      })
    }
  }
}
</script>
