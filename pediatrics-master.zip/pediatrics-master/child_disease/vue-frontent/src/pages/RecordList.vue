<template>
  <div class="row">
    <div class="col-md-12">
      <h2> 诊疗记录
        <a class="btn btn-success"
          v-link="{
            name: 'record',
            params: {patientId: patientId, recordId: 0},
            query: {mode: 'edit'}}"
          style="float: right;">添加</a>
      </h2>
      <hr>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-body">
          <editable-table
            name="records"
            :rows="rows"
            :header="tableHeader"
            :actions="tableActions"
          ></editable-table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import EditableTable from '../components/EditableTable'
import ajax from '../util/ajax'
import map from 'lodash/map'

export default {
  components: {
    EditableTable
  },

  data () {
    return {
      records: this.$root.store.records,
      patientId: this.$route.params.patientId,
      tableHeader: [
        {name: 'id', verboseName: 'id'},
        {name: 'date', verboseName: '诊疗日期'},
        {name: 'eeg_result', verboseName: '脑电图印象'},
        {name: 'diagnose', verboseName: '诊断结果'}
      ],
      tableActions: [
        {verboseName: '查看', name: 'view'},
        {name: 'delete', verboseName: '删除'},
        {name: 'edit', verboseName: '修改'}
      ]
    }
  },

  computed: {
    rows () {
      return map(this.records.items, record => {
        const recordBasic = record.Record
        const eeg = record.Eeg
        return {
          id: recordBasic.id,
          date: recordBasic.date,
          eeg_result: eeg.result,
          diagnose: recordBasic.diagnose
        }
      })
    }
  },

  events: {
    'editable-table-delete' ({rowId}) {
      ajax('/ajax/delete_model', {id: rowId, model: 'Record'})
      .then((res) => {
        this.records.deleteRecord(res)
      })
      .catch((res) => {
        this.$dispatch('error-promp', res)
      })
    },
    'editable-table-view' ({rowId}) {
      this.$route.router.go({
        name: 'record',
        params: {patientId: this.patientId, recordId: rowId},
        query: {mode: 'view'}
      })
    },
    'editable-table-edit' ({rowId}) {
      this.$route.router.go({
        name: 'record',
        params: {patientId: this.patientId, recordId: rowId},
        query: {mode: 'edit'}
      })
    }
  }
}
</script>

<style scoped>
.panel {
  min-height: 600px;
}
</style>
