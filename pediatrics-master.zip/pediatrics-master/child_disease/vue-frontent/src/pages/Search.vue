<template>
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-body">
        <div class="row search-header">
          <div class="col-md-8 col-md-offset-2">
            <div class="row">
              <div class="col-md-12">
                <h2>搜索病人
                  <radio-group
                    class="pull-right"
                    :value.sync='mode'
                    type="primary"
                  >
                    <radio-btn
                      value="normal"
                    >普通</radio-btn>
                    <radio-btn
                      value="advance"
                    >高级</radio-btn>
                  </radio-group>
                </h2>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="row">
                  <div class="col-md-5 col-xs-5" v-if="mode === 'advance'">
                    <div class="form-group">
                      <label>目标表</label>
                      <select v-model="model" class="form-control">
                        <option
                          v-for="(modelName, value) in searchModels"
                          :value="modelName"
                        >{{modelName | verbose}}</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-5 col-xs-5" v-if="mode === 'advance'">
                    <div class="form-group">
                      <label>目标字段</label>
                      <select v-model="field" class="form-control">
                        <option
                          v-for="(fieldName, value) in searchModels[model]"
                          :value="fieldName"
                        >{{fieldName | verbose}}</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-2 col-xs-2" v-if="mode === 'advance'">
                    <div class="form-group">
                      <label class="control-label pull-right">显示病例</label>
                      <button
                        class="btn btn-default pull-right"
                        :class="{'btn-success': showRecords, 'active': showRecords}"
                        @click="handleShowRecordsClick"
                      >{{showRecords ? '显示' : '隐藏'}}</button>
                    </div>
                  </div>
                  <div class="col-md-12 col-xs-12">
                    <div class="form-group">
                      <label class="control-label" v-if="mode === 'normal'">搜索内容</label>
                      <div class="input-group" v-if="mode === 'normal'">
                        <input type="text" class="form-control" v-model="query" @keypress="handleEnterPress">
                        <div class="input-group-btn">
                          <button class="btn btn-success" @click="search()">
                            <span class="glyphicon glyphicon-search"></span>
                          </button>
                        </div>
                      </div>
                      <unit-form-control
                        v-if="mode === 'advance' && searchModels[model][field]"
                        label="搜索内容"
                        :field-meta="fieldMeta(searchModels[model][field])"
                        :data.sync="query"
                      ></unit-form-control>
                      <button class="btn btn-success" v-if="mode==='advance'" @click="search()">搜索 <i class="glyphicon glyphicon-search"></i></button>
                      <span class="help-block">
                        <i class="glyphicon glyphicon-question-sign"></i>普通搜索：根据病人id和姓名来搜索
                        <span class="pull-right">搜索结果: {{numPatients}} 人</span>
                      </span>
                      <span class="help-block">
                        <i class="glyphicon glyphicon-question-sign"></i>高级搜索：根据某个字段来搜索
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <!-- search result -->
            <div class="result-header row">
              <div class="col-md-2 col-xs-2">{{'id' | verbose}}</div>
              <div class="col-md-2 col-xs-2">{{'patient_name' | verbose}}</div>
              <div class="col-md-2 col-xs-2">{{'birth_date' | verbose}}</div>
              <div class="col-md-2 col-xs-2">{{'age' | verbose}}</div>
              <div class="col-md-2 col-xs-2">{{'gender' | verbose}}</div>
              <div class="col-md-2 col-xs-2">{{'num_records' | verbose}}</div>
            </div>
            <div class="row result-row" v-for="row in rows">
              <div class="col-md-12">
                <div class="row result-patient-row" @click="viewPatient(row.id)">
                  <div class="col-md-2 col-xs-2">{{row.id}}</div>
                  <div class="col-md-2 col-xs-2">{{row.patient_name}}</div>
                  <div class="col-md-2 col-xs-2">{{row.birth_date}}</div>
                  <div class="col-md-2 col-xs-2">{{row.birth_date | age}}</div>
                  <div class="col-md-2 col-xs-2">{{row.gender | verbose 'Patient' 'gender'}}</div>
                  <div class="col-md-2 col-xs-2">{{row.num_records}}</div>
                </div>
                <!-- record list -->
                <div
                  v-show="showRecords"
                  class="row result-record-row"
                  v-for="record in row.records"
                  @click="viewRecord(row.id, record.id)">
                  <div class="col-md-12">
                    <div class="col-md-1 col-xs-2">
                      <span class="badge">诊疗记录</span>
                    </div>
                    <div class="col-md-1 col-xs-2">
                      <label>ID:</label> {{record.id}}
                    </div>
                    <div class="col-md-3 col-xs-3">
                      <label>日期:</label> {{record.date}}
                    </div>
                    <div class="col-md-4 col-xs-4">
                      <label>{{field | verbose}}:</label>
                      {{record.extra | verbose model field}}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12" style="text-align: center">
            <pagination
              :num-pages="numPages"
            ></pagination>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</template>

<script>
import {radioGroup, radioBtn} from 'vue-strap'
import UnitFormControl from '../components/UnitFormControl'
import pickBy from 'lodash/pickBy'
import ajax from '../util/ajax'
import EditableTable from '../components/EditableTable'
import Pagination from '../components/Pagination'
import fieldMeta from '../util/fieldMeta'

export default {
  data () {
    return {
      // search query
      query: '',
      // search model name
      field: '',
      model: '',
      mode: 'normal',
      searchResult: this.$root.store.searchResult,
      models: this.$root.store.models,
      // number of pages
      numPages: 0,
      numPatients: 0,
      // whether show the records
      showRecords: true
    }
  },

  components: {
    EditableTable,
    radioBtn,
    radioGroup,
    Pagination,
    UnitFormControl
  },

  computed: {
    searchModels () {
      return pickBy(this.models.items, (model, name) => {
        return /Patient|Record|Eeg/.test(name)
      })
    },
    rows () {
      return this.searchResult.getOrderedResult()
    }
  },

  methods: {
    fieldMeta,
    handleEnterPress (e) {
      if (e.keyCode === 13) {
        this.search()
      }
    },
    handleShowRecordsClick () {
      this.showRecords = !this.showRecords
    },
    search (page = 1, perPage = 10) {
      let queryObject = {
        query: this.query,
        page_num: page,
        per_page: perPage
      }

      if (this.mode === 'advance') {
        queryObject.model = this.model
        queryObject.field = this.field
      }

      ajax('/ajax/search_patient', queryObject)
      .then((res) => {
        const result = res.items
        this.numPages = res.num_pages
        this.numPatients = res.num_patients
        this.searchResult.setResult(result)
        this.$dispatch('success-act')
      })
      .catch((res) => {
        this.$dispatch('error-promp', res)
      })
    },
    viewPatient (patientId) {
      this.$route.router.go({name: 'patient', params: {patientId}, query: {mode: 'view'}})
    },
    viewRecord (patientId, recordId) {
      this.$route.router.go({name: 'record', params: {patientId, recordId}, query: {mode: 'view'}})
    }
  },

  events: {
    'pagination-change' (page) {
      this.search(page)
    }
  }
}

</script>

<style lang="scss" scoped>
.panel-body {
  min-height: 500px;
  padding-top: 0;
}
.search-header {
  background-color: #f8f8f8;
  padding-bottom: 15px;
}
.result-header {
  font-weight: bold;
  padding: 10px 0;
  background-color: #f8f8f8;
  border-bottom: 1px solid #ddd;
}
.result-row {
  .result-patient-row {
    padding: 15px 0;
  }
  .result-record-row {
    padding: 10px 0;
    padding-left: 50px;
    position: relative;
    &:before {
      display: block;
      position: absolute;
      top: 0;
      content: ' ';
      width: 2px;
      height: 44px;
      background-color: #d7d7d7;
    }
  }
  .result-patient-row:hover, .result-record-row:hover {
    background-color: #f6f6f6;
    cursor: pointer;
  }
}
</style>
