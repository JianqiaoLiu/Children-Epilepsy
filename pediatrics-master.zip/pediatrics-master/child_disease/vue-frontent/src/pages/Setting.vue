<template>
<two-col-frame>
  <left-navigator
    slot="left"
    :menu="menu"
  ></left-navigator>
  <router-view slot="right"></router-view>
</two-col-frame>
</template>

<script type="text/javascript">
import TwoColFrame from './TwoColFrame'
import LeftNavigator from '../components/LeftNavigator'

export default {
  data () {
    return {
      menu: [
        {name: '选项设置', link: '/setting/option'}
      ]
    }
  },
  components: {
    LeftNavigator,
    TwoColFrame
  }
}
</script>
