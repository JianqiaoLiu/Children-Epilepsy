<template>
<div class="row">
  <div class="col-md-2 left hidden-print">
    <slot name="left"></slot>
  </div>
  <div class="col-md-10 right">
    <slot name="right"></slot>
  </div>
</div>
</template>

<script>
export default {}
</script>

<style scoped lang="scss">
.left {
  background-color: #fff;
  border: 1px solid #ddd;
  padding: 20px 15px;
}
</style>
