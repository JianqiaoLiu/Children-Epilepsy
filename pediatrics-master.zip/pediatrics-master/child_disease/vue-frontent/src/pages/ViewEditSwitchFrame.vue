<template>
<div class="row">
  <div class="col-md-12">
    <h2>{{title}}
      <radio-group
        class="hidden-print pull-right"
        :value.sync='mode'
        type="primary"
      >
        <radio-btn
          value="view"
        >查看</radio-btn>
        <radio-btn
          value="edit"
        >编辑</radio-btn>
      </radio-group>
    </h2>
    <hr>
  </div>
</div>
<div class="row">
  <div class="col-md-12">
    <slot
      v-if="mode === 'view'"
      name="view"
    ></slot>
    <slot
      v-if="mode === 'edit'"
      name="edit"
    ></slot>
  </div>
</div>
</template>

<script type="text/javascript">
import {radioGroup, radioBtn} from 'vue-strap'

export default {
  components: {
    radioGroup, radioBtn
  },
  computed: {
    mode: {
      get () {
        return this.$route.query.mode
      },
      set (newValue) {
        const name = this.$route.name
        this.$route.router.go({name, query: {mode: newValue}})
      }
    }
  },
  props: ['title']
}

</script>
