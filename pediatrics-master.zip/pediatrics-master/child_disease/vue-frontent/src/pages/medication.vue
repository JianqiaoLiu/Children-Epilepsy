<template>
<div class="row">
  <div class="col-md-12">
    <h1>
      {{patientName}} 的用药记录
      <div class="control" style="float: right;">
        <button class="btn btn-success" @click="showModal()">添加</button>
      </div>
    </h1>
    <hr>
  </div>
</div>
<div class="row">
  <div class="col-md-12 main">
    <timeline
      :data="timelineData"
    ></timeline>
    <hr>
    <div class="panel panel-default">
      <div class="panel-body">
        <table class="table table-hover">
          <thead>
            <tr>
              <th
                v-for="meta in medicationMeta"
              >
                {{meta.name | verbose}}
              </th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="row in rows"
              @click="showModal(row.id)"
            >
              <td
                v-for="meta in medicationMeta"
              >
                {{row[meta.name] | verbose meta.model meta.name}}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="panel-default panel modal" v-show="modalShow">
      <div class="panel-body">
        <div class="row">
          <div class="col-md-12">
            <button aria-bale="close" class="close" @click="modalShow = false">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <auto-form
              :data="medication['Medication']"
              model="Medication"
              :meta="models.items['Medication']"
              @auto-form-submit="submit"
            ></auto-form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</template>

<script>
import AutoForm from '../components/AutoForm'
import Timeline from '../components/Timeline'
import ajax from '../util/ajax'
import map from 'lodash/map'
import sortBy from 'lodash/sortBy'
import verbose from '../filter/verbose'
import {createMedication} from '../util/model'

export default {
  components: {
    AutoForm,
    Timeline
  },

  data () {
    return {
      models: this.$root.store.models,
      medicationId: null,
      medications: this.$root.store.medications,
      modalShow: false,
      dataReady: false
    }
  },

  computed: {
    patient () {
      return this.$root.store.currentPatient
    },
    patientId () {
      return this.$route.params.patientId
    },
    record () {
      return this.$root.store.currentRecord
    },
    medicationMeta () {
      return sortBy(map(this.models.items.Medication, (meta) => meta), 'order')
    },
    medication () {
      return this.medications.items[this.medicationId] || createMedication()
    },
    rows () {
      return sortBy(map(this.medications.items, (v) => v.Medication), 'start_date')
    },
    patientName () {
      return this.patient && this.patient.Patient && this.patient.Patient.patient_name
    },
    timelineData () {
      return map(this.medications.items, (medication) => {
        const data = medication.Medication
        return {
          id: data.id,
          label: verbose(data.medicine, 'Medication', 'medicine'),
          startTime: new Date(data.start_date),
          endTime: new Date(data.end_date)
        }
      })
    }
  },

  methods: {
    sortBy, map,
    submit ({modelName, data}) {
      // TODO: it's bad mutating the data
      data.patient = this.patientId
      ajax('/ajax/update_model', {
        data, model_name: modelName
      }, 'json')
      .then((res) => {
        this.medications.updateMedication(parseInt(res), {
          ...this.medication,
          [modelName]: {
            ...data,
            id: res
          }
        })
        this.modalShow = false
      })
    },
    showModal (id) {
      this.medicationId = id
      this.modalShow = true
    }
  },
  events: {
    'timeline-node-click' (id) {
      this.showModal(id)
    }
  }
}
</script>

<style scoped lang="scss">
.modal {
  display: block;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 600px;
  height: 500px;
}
</style>
