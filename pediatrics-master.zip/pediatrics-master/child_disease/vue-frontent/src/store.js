import Vue from 'vue'
import keyBy from 'lodash/keyBy'
// import uniq from 'lodash/uniq'
import find from 'lodash/find'
// import {verifyRecord} from './util/model'

const set = Vue.set
const del = Vue.delete

export default {
  currentPatient: null,
  searchResult: {
    order: [],
    items: {},
    setResult (result) {
      // convert to map and then preserve the oreder
      this.items = keyBy(result, (r) => r.id)
      this.order = result.map(r => r.id)
    },
    getOrderedResult () {
      return this.order.map(key => this.items[key])
    }
  },

  // store current patient records
  records: {
    items: {},
    updateRecord (id, record) {
      // make sure the record is complete
      // if (verifyRecord(record)) {
      //   throw Error('record is not complete')
      // }
      this.items = {
        ...this.items,
        [id]: record
      }
    },
    setRecords (records) {
      this.items = records
    },
    deleteRecord (id) {
      del(this.items, id)
    }
  },

  medications: {
    items: {},
    updateMedication (id, medication) {
      this.items = {
        ...this.items,
        [id]: medication
      }
    },
    setMedications (medications) {
      this.items = medications
    },
    deleteMedication (id) {
      del(this.items, id)
    }
  },

  models: {
    items: {},
    /**
     * find a meta info using only field name
     * @param  {[type]} fieldName [description]
     * @return {[type]}           [description]
     */
    findMeta (fieldName) {
      for (let modelMeta in this.items) {
        if (this.items[modelMeta][fieldName]) {
          return this.items[modelMeta][fieldName]
        }
      }
    },
    setMetas (meta) {
      this.items = meta
    }
  },

  options: {
    items: {},
    setOptions (options) {
      this.items = options
    },
    deleteOption (model, id) {
      del(this.items[model], id)
    },
    addOption (model, id, option) {
      set(this.items[model], id, option)
    }
  },

  annotates: {
    items: {},
    getAnnotate (model, field, objectId) {
      return find(this.items, (item) => {
        return item.model === model &&
          item.field === field &&
          item.object_id === objectId
      }) || {}
    },
    setAnnotates (annotates) {
      this.items = {
        ...this.items,
        ...keyBy(annotates, (annotate) => {
          return annotate.id
        })
      }
    },
    deleteAnnotate (id) {
      if (this.items[id]) {
        del(this.items, id)
      }
    },
    setAnnotate (annotate) {
      this.items = {
        ...this.items,
        ...{[annotate.id]: annotate}
      }
    }
  }
}
