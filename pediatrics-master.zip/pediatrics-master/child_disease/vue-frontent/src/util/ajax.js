function getCookie (name) {
  var value = null
  if (document.cookie && document.cookie !== '') {
    value = document.cookie.split(';').filter((v) => {
      return v.trim().startsWith(name + '=')
    })
  }

  try {
    var ret = decodeURIComponent(value[0].split('=')[1])
  } catch (e) {
    console.log(e)
  }
  return ret
}

const CSRFToken = getCookie('csrftoken')

export function ajax (url, data, method = 'post') {
  const value = method === 'post'
    ? data &&
    Object
      .keys(data)
      .map((key) => `${key}=${encodeURIComponent(data[key])}`).join('&')
      : JSON.stringify(data)

  /*global XMLHttpRequest*/
  return new Promise(
    (resolve, reject) => {
      const xhr = new XMLHttpRequest()
      xhr.open('POST', url)

      xhr.addEventListener('load', () => {
        resolve({res: xhr.response, xhr})
      })
      xhr.addEventListener('error', reject)

      xhr.setRequestHeader('Accept', 'application/json, text/javascript, */*')

      if (method === 'json') {
        xhr.setRequestHeader('Content-Type', 'application/json;utf-8')
      } else {
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded')
      }

      xhr.setRequestHeader('X-CSRFToken', CSRFToken)
      xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest')

      xhr.send(value)
    }
  ).then(({res, xhr}) => {
    // error occurs during ajax request
    if (xhr.status !== 200) {
      throw Error('Ajax reject with code: ' + xhr.status)
    }
    const resObject = JSON.parse(res)
    if (resObject.status !== 200) {
      throw Error('Ajax reject with code: ' + resObject.status)
    }
    return resObject.content
  })
}

export default ajax
