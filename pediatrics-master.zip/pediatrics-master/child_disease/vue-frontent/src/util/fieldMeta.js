export default function (meta) {
  let fieldMeta = {
    ...meta,
    // field info override meta info if has the same key
    // deduced form control type
    type: deduceType(meta)
  }
  // when a single select with no choices
  // that should be a boolean select and we provide choices here
  if (
    fieldMeta.type === 'select' &&
    fieldMeta.choices.length === 0 &&
    meta.django_type.indexOf('Boolean') !== -1
  ) {
    fieldMeta.choices = [
      {name: '是', id: true},
      {name: '否', id: false}
    ]
  }
  return fieldMeta
}

function deduceType (meta) {
  const {django_type, choices, multiple, max_length} = meta
  // field with choices, use select control
  if (
    ((choices && choices.length > 0) ||
    django_type === 'ForeignKey') &&
    !multiple
  ) {
    return 'select'
  }
  if (multiple) {
    return 'multiple'
  }
  if (max_length > 200) {
    return 'textarea'
  }

  if (/Char/.test(django_type)) {
    return 'text'
  } else if (/Date/.test(django_type)) {
    return 'date'
  } else if (/Integer|Float/.test(django_type)) {
    return 'number'
  } else if (/Boolean/.test(django_type)) {
    return 'select'
  } else {
    return 'text'
  }
}
