import store from '../store'
import mapValues from 'lodash/mapValues'
/**
 * create an empty models
 * @param  {Array} models array of models you want to create from
 * @param  {Object}   the initial value of the object
 * @param  {Object} annotate  the annotate that adds to all Model
 * @return {Object}       the result empty model
 */
export function createModelData (models, {initialValue, annotate}) {
  let result = {}
  models.forEach((model) => {
    const modelMeta = store.models.items[model]
    if (modelMeta) {
      result[model] = mapValues(modelMeta, (field) => {
        if (/ManyToMany/.test(field.django_type)) {
          return []
        } else {
          return null
        }
      })
      result[model] = {
        ...result[model],
        ...annotate
      }
    }
  })
  return {
    ...result,
    ...initialValue
  }
}

export function createPatient ({initialValue = {}, annotate = {}} = {}) {
  return createModelData([
    'Patient', 'Disease_History', 'Family', 'Growth_History',
    'Labor_History', 'Pregnant_History'
  ], {initialValue, annotate})
}

export function createRecord ({initialValue = {}, annotate = {}} = {}) {
  return createModelData([
    'Record', 'Ct', 'Eeg', 'Mri', 'Outbreak', 'Prognosis'
  ], {initialValue, annotate})
}

export function createMedication ({initialValue = {}, annotate = {}} = {}) {
  return createModelData([
    'Medication'
  ], {initialValue, annotate})
}

export function verifyRecord (record) {
  return record.Ct && record.Eeg && record.Mri &&
    record.Outbreak && record.Prognosis && record.Record
}

export function verifyPatient (patient) {
  return patient.Patient && patient.Disease_History &&
  patient.Family && patient.Growth_History && patient.Labor_History &&
  patient.Pregnant_History
}
